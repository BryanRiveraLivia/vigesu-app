module.exports = {

"[project]/src/shared/hooks/usePageTitle.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "usePageTitle": (()=>usePageTitle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$utils$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/utils.tsx [app-ssr] (ecmascript)");
;
;
;
const usePageTitle = ()=>{
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const [pageTitle, setPageTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (pathname) {
            const title = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$utils$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLastPathSegmentFormatted"])(pathname);
            setPageTitle(title);
        }
    }, [
        pathname
    ]);
    return pageTitle;
};
}}),
"[project]/src/shared/utils/generatePDF.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "generatePDF": (()=>generatePDF)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html2canvas$2d$pro$2f$dist$2f$html2canvas$2d$pro$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/html2canvas-pro/dist/html2canvas-pro.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jspdf$2f$dist$2f$jspdf$2e$es$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jspdf/dist/jspdf.es.min.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$stores$2f$useLoadinStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/stores/useLoadinStore.ts [app-ssr] (ecmascript)");
;
;
;
const generatePDF = async (elementId, fileName = "documento.pdf")=>{
    try {
        // ✅ Acceder al store global sin usar hook React
        const { setLoading } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$stores$2f$useLoadinStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLoadingStore"].getState();
        const element = document.getElementById(elementId);
        if (!element) {
            throw new Error(`Elemento con id "${elementId}" no encontrado`);
        }
        setLoading(true, "Generate PDF ...");
        // ✅ Clonamos el nodo para capturar TODO el contenido sin recorte
        const clone = element.cloneNode(true);
        clone.style.height = "auto";
        clone.style.maxHeight = "none";
        clone.style.overflow = "visible";
        clone.style.position = "absolute";
        clone.style.left = "-9999px";
        clone.style.top = "0";
        document.body.appendChild(clone);
        // ✅ Capturamos imagen completa
        const canvas = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html2canvas$2d$pro$2f$dist$2f$html2canvas$2d$pro$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(clone, {
            scale: 2,
            useCORS: true,
            allowTaint: true,
            windowWidth: clone.scrollWidth,
            windowHeight: clone.scrollHeight
        });
        const imgData = canvas.toDataURL("image/png");
        // ✅ Crear PDF
        const pdf = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jspdf$2f$dist$2f$jspdf$2e$es$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsPDF"]({
            orientation: "portrait",
            unit: "px",
            format: "a4"
        });
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgHeight = canvas.height * pdfWidth / canvas.width;
        if (imgHeight <= pdfHeight) {
            pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, imgHeight);
        } else {
            let y = 0;
            while(y < canvas.height){
                const pageCanvas = document.createElement("canvas");
                pageCanvas.width = canvas.width;
                pageCanvas.height = Math.min(canvas.height - y, canvas.width * 1.414);
                const ctx = pageCanvas.getContext("2d");
                ctx?.drawImage(canvas, 0, y, canvas.width, pageCanvas.height, 0, 0, canvas.width, pageCanvas.height);
                const pageData = pageCanvas.toDataURL("image/png");
                pdf.addImage(pageData, "PNG", 0, 0, pdfWidth, pageCanvas.height * pdfWidth / pageCanvas.width);
                y += pageCanvas.height;
                if (y < canvas.height) pdf.addPage();
            }
        }
        pdf.save(fileName);
        document.body.removeChild(clone);
    } catch (error) {
        console.error("❌ Error generando PDF:", error);
    } finally{
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$stores$2f$useLoadinStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLoadingStore"].getState().setLoading(false);
    }
};
}}),
"[project]/src/shared/img/logoQMSFORM.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logoQMSFORM.ffc62afc.png");}}),
"[project]/src/shared/img/logoQMSFORM.png.mjs { IMAGE => \"[project]/src/shared/img/logoQMSFORM.png (static in ecmascript)\" } [app-ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$img$2f$logoQMSFORM$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/img/logoQMSFORM.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$img$2f$logoQMSFORM$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 165,
    height: 46,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR42gFCAL3/AKHO1v+b07b/0ufg/8zg6//T5O7/0uPu/8/h7P/k7vT/ANXn7v+73tz/4+/y/87h7P/L3+v/w9ro/6zM3//h7PP/Pv444zzVrvEAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 2
};
}}),
"[project]/src/shared/img/logoPremier.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logoPremier.a83ccd3d.png");}}),
"[project]/src/shared/img/logoPremier.png.mjs { IMAGE => \"[project]/src/shared/img/logoPremier.png (static in ecmascript)\" } [app-ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$img$2f$logoPremier$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/img/logoPremier.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$img$2f$logoPremier$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 212,
    height: 89,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAAVklEQVR42gFLALT/ALXXxa/RwMLUy7jOw6bDtLLOwNjq4eXx6wCPw6mMwKZ+uZt6tph7t5htr417t5jB3c8A8vf009jVw8rGwMjEytLOvcbBvsbC293cyt81svCT4FEAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 3
};
}}),

};

//# sourceMappingURL=src_shared_5ccb0c07._.js.map