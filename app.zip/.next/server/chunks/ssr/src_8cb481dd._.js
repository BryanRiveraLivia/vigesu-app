module.exports = {

"[project]/src/features/orders/store/inspection/inspectionFullStore.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/shared/store/inspection/inspectionFullStore.ts
__turbopack_context__.s({
    "useInspectionFullStore": (()=>useInspectionFullStore)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-ssr] (ecmascript)");
;
;
const useInspectionFullStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["persist"])((set)=>({
        fullInspection: null,
        fullQuestion: null,
        groupName: "",
        groupId: 0,
        titleQuestion: "",
        stepWizard: 1,
        completeStep1: false,
        completeStep2: false,
        completeStep3: false,
        completeStep4: false,
        groupedQuestions: {},
        resetTrigger: 0,
        setGroupedQuestions: (data)=>set({
                groupedQuestions: data
            }),
        incrementResetTrigger: ()=>set((state)=>({
                    resetTrigger: state.resetTrigger + 1
                })),
        setCompleteStep1: (complete)=>set({
                completeStep1: complete
            }),
        setCompleteStep2: (complete)=>set({
                completeStep2: complete
            }),
        setCompleteStep3: (complete)=>set({
                completeStep3: complete
            }),
        setCompleteStep4: (complete)=>set({
                completeStep4: complete
            }),
        setTitleQuestion: (title)=>set({
                titleQuestion: title
            }),
        setFullInspection: (data)=>set({
                fullInspection: {
                    ...data,
                    statusInspectionConfig: typeof data.statusInspectionConfig === "boolean" ? data.statusInspectionConfig : false,
                    questions: data.questions.map((q)=>({
                            ...q,
                            statusInspectionConfig: typeof q.statusInspectionConfig === "boolean" ? q.statusInspectionConfig : false
                        }))
                }
            }),
        setFullQuestion: (question)=>set({
                fullQuestion: question
            }),
        setGroupName: (name)=>set({
                groupName: name
            }),
        setGroupId: (id)=>set({
                groupId: id
            }),
        setStepWizard: (step)=>set({
                stepWizard: step
            }),
        resetFullInspection: ()=>set((state)=>({
                    fullInspection: null,
                    fullQuestion: null,
                    groupName: "",
                    groupId: 0,
                    titleQuestion: "",
                    stepWizard: 1,
                    completeStep1: false,
                    completeStep2: false,
                    completeStep3: false,
                    completeStep4: false,
                    groupedQuestions: {},
                    resetTrigger: state.resetTrigger + 1
                }))
    }), {
    name: "inspection-full-storage"
}));
}}),
"[project]/src/features/orders/inspections/components/Wizard.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/store/inspection/inspectionFullStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
;
;
;
const Wizard = ()=>{
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("inspections");
    const { stepWizard, completeStep1, completeStep2, completeStep3, setStepWizard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"])();
    const goToStep = (step)=>{
        const store = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState();
        switch(step){
            case 1:
                if (completeStep1) store.setStepWizard(1);
                break;
            case 2:
                if (completeStep1) store.setStepWizard(2);
                break;
            case 3:
                if (completeStep2) store.setStepWizard(3);
                break;
            case 4:
                if (completeStep3) store.setStepWizard(4);
                break;
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
        className: "steps w-full mb-10 transition-all",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                onClick: ()=>goToStep(1),
                className: `step transition-all ${stepWizard >= 1 ? "step-neutral" : ""} ${completeStep1 ? "cursor-pointer" : "cursor-not-allowed"}`,
                children: t("wizard.1")
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/Wizard.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                onClick: ()=>goToStep(2),
                className: `step transition-all ${stepWizard >= 2 ? "step-neutral" : ""} ${completeStep1 ? "cursor-pointer" : "cursor-not-allowed"}`,
                children: t("wizard.2")
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/Wizard.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                onClick: ()=>goToStep(3),
                className: `step transition-all ${stepWizard >= 3 ? "step-neutral" : ""} ${completeStep2 ? "cursor-pointer" : "cursor-not-allowed"}`,
                children: t("wizard.3")
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/Wizard.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                onClick: ()=>goToStep(4),
                className: `step transition-all !hidden ${stepWizard >= 4 ? "step-neutral" : ""} ${completeStep3 ? "cursor-pointer" : "cursor-not-allowed"}`,
                children: t("wizard.4")
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/Wizard.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/features/orders/inspections/components/Wizard.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = Wizard;
}}),
"[project]/src/features/orders/create-order/ImageUploader.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dropzone$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-dropzone/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dropzone$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/react-dropzone/dist/es/index.js [app-ssr] (ecmascript) <locals>");
"use client";
;
;
;
;
const ImageUploader = ({ onFilesChange, accept = {
    "image/*": [],
    "application/pdf": []
} })=>{
    const [files, setFiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const tUploadPhoto = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("uploadPhoto");
    const onDrop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((acceptedFiles)=>{
        const renamedFiles = acceptedFiles.map((file)=>{
            const extension = file.name.split(".").pop();
            const timestamp = new Date().toISOString().replace(/[-:.TZ]/g, "");
            const uniqueId = crypto.randomUUID(); // o usa uuidv4()
            const newName = `${timestamp}-${uniqueId}.${extension}`;
            return new File([
                file
            ], newName, {
                type: file.type
            });
        });
        const updated = [
            ...files,
            ...renamedFiles
        ];
        setFiles(updated);
        onFilesChange?.(updated);
    }, [
        files,
        onFilesChange
    ]);
    const removeFile = (indexToRemove)=>{
        const updated = files.filter((_, i)=>i !== indexToRemove);
        setFiles(updated);
        onFilesChange?.(updated);
    };
    const { getRootProps, getInputProps, isDragActive } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dropzone$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDropzone"])({
        accept,
        onDrop,
        multiple: true
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "font-bold mb-2",
                children: tUploadPhoto("attach")
            }, void 0, false, {
                fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ...getRootProps(),
                className: "border-1 border-dashed border-gray-300 p-4 rounded-md text-center cursor-pointer bg-[#f6f3f4] py-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ...getInputProps({
                            capture: "environment"
                        }),
                        style: {
                            display: "none",
                            width: 0,
                            height: 0,
                            position: "absolute",
                            overflow: "hidden",
                            opacity: 0,
                            pointerEvents: "none"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: isDragActive ? tUploadPhoto("drop") : tUploadPhoto("upload")
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            files.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 flex flex-wrap gap-2",
                children: files.map((file, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative border rounded-md overflow-hidden w-[100px] h-[100px] flex-shrink-0",
                        children: [
                            file.type.startsWith("image/") ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: URL.createObjectURL(file),
                                alt: `preview-${index}`,
                                className: "w-full h-full object-cover"
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                                lineNumber: 77,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-center h-full bg-gray-200 text-xs text-center px-2",
                                children: file.name
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                                lineNumber: 83,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>removeFile(index),
                                type: "button",
                                className: "absolute top-1 right-1 bg-white bg-opacity-70 rounded-full w-5 h-5 text-xs flex items-center justify-center hover:bg-red-500 hover:text-white cursor-pointer",
                                title: "Remove",
                                children: "×"
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                                lineNumber: 87,
                                columnNumber: 15
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                        lineNumber: 72,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
                lineNumber: 70,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/features/orders/create-order/ImageUploader.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = ImageUploader;
}}),
"[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const EmailConfirmationModal = ({ open, onClose, onConfirm, userName })=>{
    const tToasts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("toast");
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("bryan.riv09@gmail.com");
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleSend = async ()=>{
        if (!email.includes("@")) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].warning(`${tToasts("warning")}: ${tToasts("msj.25")}`);
            return;
        }
        try {
            setLoading(true);
            const res = await fetch("/api/send-inspection-email", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email,
                    name: userName
                })
            });
            const json = await res.json();
            if (!res.ok || json.error) throw new Error("Fallo al enviar correo");
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(`${tToasts("ok")}: ${tToasts("msj.26")}`);
            onClose();
            onConfirm(); // Ejecuta handleFinalSubmit
        } catch (err) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(`${tToasts("error")}: ${tToasts("msj.27")}`);
            console.error(err);
        } finally{
            setLoading(false);
        }
    };
    if (!open) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed z-50 inset-0 bg-black/50 flex items-center justify-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-lg p-6 w-full max-w-md shadow-xl space-y-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-lg font-semibold",
                    children: "Enter your email"
                }, void 0, false, {
                    fileName: "[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx",
                    lineNumber: 57,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "email",
                    className: "input input-bordered w-full",
                    placeholder: "example@email.com",
                    value: email,
                    onChange: (e)=>setEmail(e.target.value)
                }, void 0, false, {
                    fileName: "[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end gap-2 pt-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "btn btn-ghost",
                            onClick: onClose,
                            disabled: loading,
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx",
                            lineNumber: 66,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "btn bg-black text-white",
                            onClick: handleSend,
                            disabled: loading,
                            children: loading ? "Sending..." : "Send"
                        }, void 0, false, {
                            fileName: "[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx",
            lineNumber: 56,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx",
        lineNumber: 55,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = EmailConfirmationModal;
}}),
"[project]/src/features/orders/inspections/components/GenerateStep1.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/utils/axiosInstance.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$Loading$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/components/shared/Loading.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/store/inspection/inspectionFullStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$Wizard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/Wizard.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/bs/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$create$2d$order$2f$ImageUploader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/create-order/ImageUploader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$stores$2f$useAuthUser$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/stores/useAuthUser.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$EmailConfirmationModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/EmailConfirmationModal.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const GenerateStep1 = ({ ClientName })=>{
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("inspections");
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const tToasts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("toast");
    const { userName, employeeName, rol, employeeId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$stores$2f$useAuthUser$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAuthUser"])();
    const [inspectionFiles, setInspectionFiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { groupedQuestions, fullInspection, setStepWizard, setCompleteStep1, setGroupedQuestions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"])();
    const goStep = async (typeInspectionId, groupName, groupId)=>{
        try {
            const store = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState();
            const previous = store.fullInspection;
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].get(`/TypeInspection/GetFullTypeInspectionId?TypeInspectionId=${typeInspectionId}`);
            // fusiona respuestas anteriores si existen
            const mergedQuestions = res.data.questions.map((q)=>{
                const prev = previous?.questions.find((pq)=>pq.typeInspectionDetailId === q.typeInspectionDetailId);
                return {
                    ...q,
                    answers: prev?.answers ?? q.answers,
                    finalResponse: prev?.finalResponse ?? "",
                    statusInspectionConfig: prev?.statusInspectionConfig ?? false
                };
            });
            store.setFullInspection({
                ...res.data,
                questions: mergedQuestions
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setGroupName(groupName);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setGroupId(groupId);
            /* const grouped = res.data.questions.reduce((acc, question) => {
          if (!acc[question.groupName]) acc[question.groupName] = [];
          acc[question.groupName].push(question);
          return acc;
        }, {} as Record<string, IFullQuestion[]>);*/ setCompleteStep1(false);
            setStepWizard(2);
        } catch (err) {
            console.error("Error al obtener datos completos de inspección", err);
        }
    };
    const extractAnswerRecursiveArray = (answers)=>{
        return answers.flatMap((answer)=>[
                {
                    ...answer
                },
                ...answer.subAnswers ? extractAnswerRecursiveArray(answer.subAnswers) : []
            ]);
    };
    const handleFinalSubmit = async ()=>{
        if (!fullInspection) return;
        // Generar lista de nombres de archivos
        const inspectionPhotoNames = inspectionFiles.map((f)=>f.name);
        const payload = {
            typeInspectionId: fullInspection.typeInspectionId,
            customerId: fullInspection.customerId,
            employeeId: employeeId?.toString(),
            customerName: ClientName.toString(),
            employeeName: employeeName?.toString(),
            dateOfInspection: new Date().toISOString(),
            inspectionDetails: fullInspection.questions.map((q)=>{
                // 🔎 Obtenemos todas las respuestas recursivas
                const flatAnswers = extractAnswerRecursiveArray(q.answers ?? []);
                return {
                    typeInspectionDetailId: q.typeInspectionDetailId,
                    typeInspectionDetailAnswerId: flatAnswers[0]?.typeInspectionDetailAnswerId ?? 0,
                    finalResponse: q.finalResponse ?? "",
                    inspectionDetailAnswers: flatAnswers.map((a)=>({
                            typeInspectionDetailAnswerId: a.typeInspectionDetailAnswerId,
                            finalResponse: a.response,
                            inspectionDetailAnswerItem: (a.selectedItems ?? []).map((item)=>({
                                    itemId: item.id,
                                    itemName: item.name,
                                    quantity: item.quantity,
                                    price: item.unitPrice
                                }))
                        }))
                };
            }),
            inspectionPhotos: inspectionFiles.map((f)=>({
                    name: f.name,
                    photoUrl: f.name
                }))
        };
        console.log("📤 Enviando payload a API:", payload);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].post("/Inspection", payload);
            const inspectionId = response.data; // ✅ número entero simple, como mencionaste
            // 2️⃣ Subir archivos si existen
            if (inspectionFiles.length > 0) {
                const formData = new FormData();
                formData.append("InspectionId", inspectionId.toString()); // ✅ ahora sí se pasa correctamente
                inspectionFiles.forEach((file)=>{
                    formData.append("Files", file); // ✅ debe coincidir con lo que espera el backend
                });
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].post("/Inspection/UploadInspectionPhotos", formData, {
                    headers: {
                        "Content-Type": "multipart/form-data"
                    }
                });
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(`${tToasts("ok")}: ${tToasts("msj.28")}`);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().resetFullInspection();
            router.push("./");
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(`${tToasts("error")}: ${tToasts("msj.29")}`);
            console.error(error);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$Wizard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                lineNumber: 187,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "",
                children: !groupedQuestions ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$Loading$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    height: "h-[300px]",
                    label: "Esperando configuración ..."
                }, void 0, false, {
                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                    lineNumber: 190,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "cont my-5 flex flex-col gap-1",
                    children: fullInspection && Object.entries(fullInspection.questions.reduce((acc, question)=>{
                        if (!acc[question.groupName]) acc[question.groupName] = [];
                        acc[question.groupName].push(question);
                        return acc;
                    }, {})).map(([groupName, questions])=>{
                        const groupId = questions[0]?.groupId;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>goStep(fullInspection.typeInspectionId, groupName, groupId),
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(`w-full flex flex-row card lg:card-side  shadow-sm overflow-hidden cursor-pointer transition-all hover:shadow-lg mb-5  text-white `, questions.every((q)=>q.statusInspectionConfig) ? `bg-green-800/80 hover:bg-green-800 hover:text-white/80` : `bg-black/80 hover:bg-[#191917] hover:text-white/80`),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(` w-fit flex items-center justify-center p-2`, questions.every((q)=>q.statusInspectionConfig) ? `bg-green-800` : `bg-[#191917]`),
                                    children: questions.every((q)=>q.statusInspectionConfig) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaCheckCircle"], {
                                        className: "w-[20px] h-[20px]  text-green-400 mx-auto"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                        lineNumber: 231,
                                        columnNumber: 25
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BsQuestionCircle"], {
                                        className: "w-[20px] h-[20px]  text-white mx-auto"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                        lineNumber: 233,
                                        columnNumber: 25
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                    lineNumber: 222,
                                    columnNumber: 21
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "card-body flex flex-row justify-between gap-5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col items-start",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "card-title text-left",
                                                    children: [
                                                        groupName,
                                                        " "
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                                    lineNumber: 238,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-lg text-left",
                                                    children: fullInspection.description
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                                    lineNumber: 239,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                            lineNumber: 237,
                                            columnNumber: 23
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "card-actions justify-end flex items-center ",
                                            children: [
                                                questions.filter((item)=>item.status === 0).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "badge badge-error text-white text-lg",
                                                    children: questions.filter((item)=>item.status === 0).length
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                                    lineNumber: 246,
                                                    columnNumber: 27
                                                }, this),
                                                questions.filter((item)=>item.status === 1).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "badge badge-success text-white text-lg",
                                                    children: questions.filter((item)=>item.status === 1).length
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                                    lineNumber: 255,
                                                    columnNumber: 27
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                            lineNumber: 243,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                                    lineNumber: 236,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, groupName, true, {
                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                            lineNumber: 206,
                            columnNumber: 19
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                    lineNumber: 192,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                lineNumber: 188,
                columnNumber: 7
            }, this),
            fullInspection?.questions.every((q)=>q.statusInspectionConfig) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$create$2d$order$2f$ImageUploader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                onFilesChange: setInspectionFiles
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                lineNumber: 271,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center mt-5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "btn font-normal bg-black text-white rounded-full pr-3 py-6 sm:flex border-none flex-1 w-full md:w-[300px] mx-auto text-[13px]",
                    disabled: !fullInspection?.questions.every((q)=>q.statusInspectionConfig),
                    onClick: ()=>setShowModal(true),
                    children: t("step1.1")
                }, void 0, false, {
                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                    lineNumber: 275,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                lineNumber: 274,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$EmailConfirmationModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                open: showModal,
                onClose: ()=>setShowModal(false),
                onConfirm: handleFinalSubmit,
                userName: employeeName || "Usuario"
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep1.tsx",
                lineNumber: 285,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = GenerateStep1;
}}),
"[project]/src/features/orders/inspections/components/GenerateStep2.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/store/inspection/inspectionFullStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/bs/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$Wizard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/Wizard.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/utils/axiosInstance.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
;
;
;
;
;
;
;
;
;
;
const GenerateStep2 = ()=>{
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("inspections");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const store = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState();
    const { fullInspection, groupName, groupId, setCompleteStep2, setCompleteStep3 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"])();
    const tToasts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("toast");
    const goStep = (question)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setStepWizard(3);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setCompleteStep2(true);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setTitleQuestion(question.question);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setFullQuestion(question);
    };
    const enableFinalButton = fullInspection?.questions.filter((item)=>item.groupName === groupName && item.groupId === groupId).filter((item)=>item.statusInspectionConfig === false).length ?? 0;
    const handleFinalSubmit = async ()=>{
        if (!fullInspection) return;
        const payload = {
            typeInspectionId: fullInspection.typeInspectionId,
            customerId: fullInspection.customerId,
            employeeId: "empleado-123",
            customerName: "Cliente Prueba",
            employeeName: "Empleado QA",
            dateOfInspection: new Date().toISOString(),
            inspectionDetails: fullInspection.questions.map((q)=>({
                    typeInspectionDetailId: q.typeInspectionDetailId,
                    typeInspectionDetailAnswerId: q.answers[0]?.typeInspectionDetailAnswerId ?? 0,
                    finalResponse: q.finalResponse ?? "",
                    inspectionDetailAnswers: q.answers.map((a)=>({
                            typeInspectionDetailAnswerId: a.typeInspectionDetailAnswerId,
                            finalResponse: a.response,
                            inspectionDetailAnswerItem: (a.selectedItems ?? []).map((item)=>({
                                    itemId: item.id,
                                    itemName: item.name,
                                    quantity: item.quantity,
                                    price: item.unitPrice
                                }))
                        }))
                })),
            inspectionPhotos: []
        };
        //console.log("📤 Enviando payload a API:", payload);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].post("/Inspection", payload);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(`${tToasts("ok")}: ${tToasts("msj.28")}`);
            //  RESET COMPLETO
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().resetFullInspection();
            router.push("./");
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(`${tToasts("error")}: ${tToasts("msj.29")}`);
            console.error(error);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$Wizard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                lineNumber: 92,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col my-10 text-center justify-items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "font-bold text-2xl",
                        children: fullInspection?.name ?? ""
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: fullInspection?.description ?? ""
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            fullInspection?.questions.filter((item)=>item.groupName === groupName && item.groupId === groupId).map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>goStep(item),
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(`w-full flex flex-row card lg:card-side  shadow-sm overflow-hidden cursor-pointer transition-all hover:shadow-lg mb-5  text-white `, !item.statusInspectionConfig ? `bg-black/80 hover:bg-[#191917] hover:text-white/80` : `bg-green-800/80 hover:bg-green-800 hover:text-white/80`),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(` w-fit flex items-center justify-center p-2`, item.statusInspectionConfig ? `bg-green-800` : `bg-[#191917]`),
                            children: item.statusInspectionConfig ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaCheckCircle"], {
                                className: "w-[20px] h-[20px]  text-green-400 mx-auto"
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                                lineNumber: 119,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BsQuestionCircle"], {
                                className: "w-[20px] h-[20px]  text-white mx-auto"
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                                lineNumber: 121,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                            lineNumber: 112,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "card-body flex flex-row justify-between gap-5",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "card-title text-left",
                                    children: item.question
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                                    lineNumber: 127,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                                lineNumber: 126,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                            lineNumber: 125,
                            columnNumber: 13
                        }, this)
                    ]
                }, index, true, {
                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                    lineNumber: 102,
                    columnNumber: 11
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center mt-5",
                children: enableFinalButton == 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    disabled: enableFinalButton > 0,
                    className: "btn font-normal bg-black text-white rounded-full pr-3 py-6 sm:flex border-none flex-1 w-fit mx-auto text-[13px]",
                    onClick: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setStepWizard(3),
                    children: [
                        t("step2.1"),
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "underline text-red-400",
                            children: t("step2.1_5")
                        }, void 0, false, {
                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                            lineNumber: 140,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                    lineNumber: 134,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep2.tsx",
                lineNumber: 132,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = GenerateStep2;
}}),
"[project]/src/shared/components/shared/tableButtons/ActionButton.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const ActionButton = ({ icon, label, onClick, className = "" })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: onClick,
        type: "button",
        className: `btn min-w-[30px] min-h-[30px] p-2 rounded-md ${className}`,
        children: [
            icon && icon,
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "hidden xl:block text-[12px] font-normal",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/tableButtons/ActionButton.tsx",
                lineNumber: 24,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/shared/components/shared/tableButtons/ActionButton.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = ActionButton;
}}),
"[project]/src/features/orders/inspections/components/ModalUsingItem.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ai/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$tableButtons$2f$ActionButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/components/shared/tableButtons/ActionButton.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2f$v4$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/uuid/dist/esm/v4.js [app-ssr] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/utils/axiosInstance.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash/debounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$Loading$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/components/shared/Loading.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
"use client";
;
;
;
;
;
;
;
;
;
;
;
const ModalUsingItem = ({ onClose, onSave, initialItems })=>{
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("inspections");
    const [isSearching, setIsSearching] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [results, setResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedItems, setSelectedItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedItem, setSelectedItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [quantity, setQuantity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    //  Debounced search function usando useRef como en tu ejemplo
    const debouncedFetch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async (term)=>{
        const q = term.trim();
        // Si no cumple el mínimo: limpia y apaga el loader
        if (q.length < 3) {
            setResults([]);
            setIsSearching(false);
            return;
        }
        try {
            setIsSearching(true);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].get("/QuickBooks/Items/GetItemName");
            const filtered = (res.data ?? []).filter((item)=>item.name.toLowerCase().includes(q.toLowerCase()));
            setResults(filtered);
        } catch (err) {
            console.error("Error fetching items:", err);
        } finally{
            setIsSearching(false);
        }
    }, 500)).current;
    const handleAddItem = ()=>{
        if (selectedItem && quantity > 0) {
            setSelectedItems((prev)=>[
                    ...prev,
                    {
                        ...selectedItem,
                        quantity,
                        _uid: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2f$v4$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()
                    }
                ]);
            setSelectedItem(null);
            setQuery("");
            setQuantity(1);
            setResults([]);
        }
    };
    const handleDeleteItem = (uid)=>{
        setSelectedItems((prev)=>prev.filter((i)=>i._uid !== uid));
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const itemsWithUid = (initialItems ?? []).map((item)=>({
                ...item,
                _uid: item._uid ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2f$v4$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()
            }));
        setSelectedItems(itemsWithUid);
    }, [
        initialItems
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>()=>debouncedFetch.cancel(), [
        debouncedFetch
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dialog", {
        open: true,
        className: "modal",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "modal-box w-11/12 max-w-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-3 flex flex-row gap-4 items-center justify-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col flex-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                                    className: "fieldset-legend text-lg font-normal",
                                    children: t("step4.1")
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                    lineNumber: 106,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            ref: inputRef,
                                            value: query,
                                            onChange: (e)=>{
                                                const value = e.target.value;
                                                setQuery(value);
                                                setSelectedItem(null);
                                                const q = value.trim();
                                                if (q.length === 0) {
                                                    // limpiar si vacío
                                                    setResults([]);
                                                    setIsSearching(false);
                                                    return;
                                                }
                                                // mostrar spinner mientras debounce corre
                                                setIsSearching(true);
                                                debouncedFetch(q); // <- tu debouncedFetch corregido llama setIsSearching(false) en finally
                                            },
                                            className: "input input-lg text-lg w-full",
                                            autoComplete: "off"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                            lineNumber: 110,
                                            columnNumber: 15
                                        }, this),
                                        results.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "bg-base-100 w-full rounded-box shadow-md z-50 max-h-60 overflow-y-auto absolute mt-1",
                                            children: results.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "cursor-pointer text-sm block w-full text-left px-4 py-2 hover:bg-gray-100",
                                                    onClick: ()=>{
                                                        // 👉 evita que se ejecute la búsqueda que ya estaba encolada
                                                        debouncedFetch.cancel();
                                                        setIsSearching(false);
                                                        setSelectedItem(item);
                                                        setQuery(item.name);
                                                        setResults([]);
                                                        setQuantity(1);
                                                    },
                                                    children: item.name
                                                }, item.id, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                                    lineNumber: 140,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                            lineNumber: 138,
                                            columnNumber: 17
                                        }, this),
                                        isSearching && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute right-3 top-1/2 -translate-y-1/2 z-20",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$Loading$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                enableLabel: false,
                                                size: "loading-sm "
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                                lineNumber: 163,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                            lineNumber: 162,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                    lineNumber: 109,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                            lineNumber: 105,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-[100px]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                                    className: "fieldset-legend text-lg font-normal",
                                    children: t("step4.2")
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                    lineNumber: 170,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "number",
                                    className: "input input-lg text-lg w-full text-center",
                                    value: quantity,
                                    onChange: (e)=>setQuantity(Number(e.target.value)),
                                    min: 1
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                    lineNumber: 173,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                            lineNumber: 169,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "btn bg-black text-white rounded-full font-bold text-2xl",
                                onClick: handleAddItem,
                                disabled: !selectedItem,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiPlus"], {}, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                    lineNumber: 189,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                lineNumber: 183,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                            lineNumber: 182,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                    lineNumber: 104,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-3 mt-5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: "table table-fixed w-full",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "w-[40%] text-center truncate",
                                            children: t("step4.3")
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                            lineNumber: 199,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "w-[40%] text-center truncate",
                                            children: t("step4.4")
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                            lineNumber: 200,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "w-[20%] text-center truncate"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                            lineNumber: 201,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                    lineNumber: 198,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                lineNumber: 197,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: selectedItems.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "odd:bg-base-200",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "text-center",
                                                children: item.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                                lineNumber: 207,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "text-center",
                                                children: item.quantity
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                                lineNumber: 208,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "text-right",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$tableButtons$2f$ActionButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiTrash2"], {
                                                        className: "w-[20px] h-[20px] opacity-70"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                                        lineNumber: 212,
                                                        columnNumber: 25
                                                    }, void 0),
                                                    label: t("step4.7"),
                                                    onClick: ()=>handleDeleteItem(item._uid)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                                    lineNumber: 210,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                                lineNumber: 209,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, item._uid, true, {
                                        fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                        lineNumber: 206,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                lineNumber: 204,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                        lineNumber: 196,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                    lineNumber: 195,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "modal-action flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "btn",
                            onClick: onClose,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IoMdClose"], {
                                    className: "w-[20px] h-[20px] opacity-70"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                    lineNumber: 227,
                                    columnNumber: 13
                                }, this),
                                " ",
                                t("step4.5")
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                            lineNumber: 226,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "btn",
                            onClick: ()=>onSave(selectedItems),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AiOutlineSave"], {
                                    className: "w-[20px] h-[20px] opacity-70"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                                    lineNumber: 235,
                                    columnNumber: 13
                                }, this),
                                t("step4.6")
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                            lineNumber: 230,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
                    lineNumber: 225,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
            lineNumber: 102,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/features/orders/inspections/components/ModalUsingItem.tsx",
        lineNumber: 101,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = ModalUsingItem;
}}),
"[project]/src/features/orders/models/workOrder.types.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "TypeInspectionOrders": (()=>TypeInspectionOrders),
    "TypeInspectionOrdersLabel": (()=>TypeInspectionOrdersLabel),
    "TypeQuestion": (()=>TypeQuestion),
    "TypeQuestionLabel": (()=>TypeQuestionLabel),
    "WorkOrderStatus": (()=>WorkOrderStatus),
    "WorkOrderStatusLabel": (()=>WorkOrderStatusLabel)
});
var WorkOrderStatus = /*#__PURE__*/ function(WorkOrderStatus) {
    WorkOrderStatus[WorkOrderStatus["Create"] = 0] = "Create";
    WorkOrderStatus[WorkOrderStatus["Disabled"] = 1] = "Disabled";
    WorkOrderStatus[WorkOrderStatus["SyncQuickbook"] = 2] = "SyncQuickbook";
    return WorkOrderStatus;
}({});
const WorkOrderStatusLabel = {
    [0]: "Create",
    [1]: "Disabled",
    [2]: "Sync Quickbook"
};
var TypeQuestion = /*#__PURE__*/ function(TypeQuestion) {
    TypeQuestion[TypeQuestion["SingleChoice"] = 0] = "SingleChoice";
    TypeQuestion[TypeQuestion["MultipleChoice"] = 1] = "MultipleChoice";
    TypeQuestion[TypeQuestion["TextInput"] = 2] = "TextInput";
    TypeQuestion[TypeQuestion["Sign"] = 3] = "Sign";
    return TypeQuestion;
}({});
const TypeQuestionLabel = {
    [0]: "Single Choice",
    [1]: "Multiple Choice",
    [2]: "Text Input",
    [3]: "by Sign"
};
var TypeInspectionOrders = /*#__PURE__*/ function(TypeInspectionOrders) {
    TypeInspectionOrders[TypeInspectionOrders["Create"] = 0] = "Create";
    TypeInspectionOrders[TypeInspectionOrders["PreAccepted"] = 1] = "PreAccepted";
    TypeInspectionOrders[TypeInspectionOrders["Accepted"] = 2] = "Accepted";
    TypeInspectionOrders[TypeInspectionOrders["Disabled"] = 3] = "Disabled";
    TypeInspectionOrders[TypeInspectionOrders["SyncQuickbook"] = 4] = "SyncQuickbook";
    return TypeInspectionOrders;
}({});
const TypeInspectionOrdersLabel = {
    [0]: "Create",
    [1]: "Pre accepted",
    [2]: "Accepted",
    [3]: "Disabled",
    [4]: "Sync Quickbook"
};
}}),
"[project]/src/assets/lotties/check.json (json)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v(JSON.parse("{\"nm\":\"Tick \",\"mn\":\"\",\"layers\":[{\"ty\":4,\"nm\":\"tick\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1506,1505,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Shape 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"sh\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Group\",\"nm\":\"Path 1\",\"ix\":1,\"d\":1,\"ks\":{\"a\":0,\"k\":{\"c\":false,\"i\":[[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0]],\"v\":[[-400,-4],[-138,258],[388,-268]]},\"ix\":2}},{\"ty\":\"st\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Stroke\",\"nm\":\"Stroke 1\",\"lc\":2,\"lj\":2,\"ml\":1,\"o\":{\"a\":0,\"k\":90,\"ix\":4},\"w\":{\"a\":0,\"k\":100,\"ix\":5},\"d\":[],\"c\":{\"a\":0,\"k\":[1,1,1],\"ix\":3}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]},{\"ty\":\"tm\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Filter - Trim\",\"nm\":\"Trim Paths 1\",\"ix\":2,\"e\":{\"a\":0,\"k\":0,\"ix\":2},\"o\":{\"a\":0,\"k\":0,\"ix\":3},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.45,\"y\":0},\"i\":{\"x\":0.2,\"y\":1},\"s\":[0],\"t\":70},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[100],\"t\":90}],\"ix\":1},\"m\":1}],\"ind\":1},{\"ty\":4,\"nm\":\"Circle 3\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.2,\"y\":1},\"s\":[0,0,100],\"t\":30},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[99,99,100],\"t\":70}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1494.667,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Shape 1\",\"ix\":1,\"cix\":2,\"np\":2,\"it\":[{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.0196,0.749,0.2627],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]},{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":2,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.0196,0.749,0.2627],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[59.194,59.194],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":2},{\"ty\":4,\"nm\":\"Circle 2\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"td\":1,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.2,\"y\":1},\"s\":[0,0,100],\"t\":20},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[99,99,100],\"t\":60}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1494.667,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.251,0.8392,0.2706],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[59.194,59.194],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":3},{\"ty\":4,\"nm\":\"Circle\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"tt\":2,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.2,\"y\":1},\"s\":[0,0,100],\"t\":0},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[99,99,100],\"t\":40}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1494.667,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.2431,0.8275,0.302],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[59.194,59.194],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":4},{\"ty\":0,\"nm\":\"Confeti 7\",\"mn\":\"\",\"sr\":1,\"st\":-1,\"op\":1799,\"ip\":-1,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.333,\"y\":0},\"i\":{\"x\":0.667,\"y\":1},\"s\":[0],\"t\":43},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[100],\"t\":53}],\"ix\":11},\"r\":{\"a\":0,\"k\":310.5,\"ix\":10}},\"ef\":[],\"w\":3000,\"h\":3000,\"refId\":\"comp_0\",\"ind\":5},{\"ty\":0,\"nm\":\"Confeti 6\",\"mn\":\"\",\"sr\":1,\"st\":-1,\"op\":1799,\"ip\":-1,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.333,\"y\":0},\"i\":{\"x\":0.667,\"y\":1},\"s\":[0],\"t\":43},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[100],\"t\":53}],\"ix\":11},\"r\":{\"a\":0,\"k\":259.5,\"ix\":10}},\"ef\":[],\"w\":3000,\"h\":3000,\"refId\":\"comp_1\",\"ind\":6},{\"ty\":0,\"nm\":\"Confeti 5\",\"mn\":\"\",\"sr\":1,\"st\":-1,\"op\":1799,\"ip\":-1,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.333,\"y\":0},\"i\":{\"x\":0.667,\"y\":1},\"s\":[0],\"t\":43},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[100],\"t\":53}],\"ix\":11},\"r\":{\"a\":0,\"k\":208,\"ix\":10}},\"ef\":[],\"w\":3000,\"h\":3000,\"refId\":\"comp_2\",\"ind\":7},{\"ty\":0,\"nm\":\"Confeti 4\",\"mn\":\"\",\"sr\":1,\"st\":-1,\"op\":1799,\"ip\":-1,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.333,\"y\":0},\"i\":{\"x\":0.667,\"y\":1},\"s\":[0],\"t\":43},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[100],\"t\":53}],\"ix\":11},\"r\":{\"a\":0,\"k\":156.5,\"ix\":10}},\"ef\":[],\"w\":3000,\"h\":3000,\"refId\":\"comp_3\",\"ind\":8},{\"ty\":0,\"nm\":\"Confeti 3\",\"mn\":\"\",\"sr\":1,\"st\":-1,\"op\":1799,\"ip\":-1,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.333,\"y\":0},\"i\":{\"x\":0.667,\"y\":1},\"s\":[0],\"t\":43},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[100],\"t\":53}],\"ix\":11},\"r\":{\"a\":0,\"k\":103,\"ix\":10}},\"ef\":[],\"w\":3000,\"h\":3000,\"refId\":\"comp_4\",\"ind\":9},{\"ty\":0,\"nm\":\"Confeti 2\",\"mn\":\"\",\"sr\":1,\"st\":-1,\"op\":1799,\"ip\":-1,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.333,\"y\":0},\"i\":{\"x\":0.667,\"y\":1},\"s\":[0],\"t\":43},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[100],\"t\":53}],\"ix\":11},\"r\":{\"a\":0,\"k\":51.5,\"ix\":10}},\"ef\":[],\"w\":3000,\"h\":3000,\"refId\":\"comp_5\",\"ind\":10},{\"ty\":0,\"nm\":\"Confeti 1\",\"mn\":\"\",\"sr\":1,\"st\":-1,\"op\":1799,\"ip\":-1,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":0,\"k\":[1500,1500,0],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.333,\"y\":0},\"i\":{\"x\":0.667,\"y\":1},\"s\":[0],\"t\":43},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[100],\"t\":53}],\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"w\":3000,\"h\":3000,\"refId\":\"comp_6\",\"ind\":11}],\"ddd\":0,\"h\":3000,\"w\":3000,\"meta\":{\"a\":\"\",\"k\":\"\",\"d\":\"\",\"g\":\"LottieFiles AE 0.1.20\",\"tc\":\"#000000\"},\"v\":\"5.5.7\",\"fr\":60,\"op\":120,\"ip\":0,\"assets\":[{\"nm\":\"\",\"mn\":\"\",\"layers\":[{\"ty\":4,\"nm\":\"pop\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.3,\"y\":1},\"s\":[5,5,100],\"t\":50},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[0,0,100],\"t\":100}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,1140,0],\"t\":31},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,260,0],\"t\":80}],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.2431,0.8275,0.302],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":1}],\"id\":\"comp_0\",\"fr\":30},{\"nm\":\"\",\"mn\":\"\",\"layers\":[{\"ty\":4,\"nm\":\"pop\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.3,\"y\":1},\"s\":[5,5,100],\"t\":50},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[0,0,100],\"t\":100}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,1140,0],\"t\":31},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,260,0],\"t\":80}],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.251,0.8392,0.2706],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":1}],\"id\":\"comp_1\",\"fr\":30},{\"nm\":\"\",\"mn\":\"\",\"layers\":[{\"ty\":4,\"nm\":\"pop\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.3,\"y\":1},\"s\":[5,5,100],\"t\":50},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[0,0,100],\"t\":100}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,1140,0],\"t\":31},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,260,0],\"t\":80}],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.251,0.8392,0.2706],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":1}],\"id\":\"comp_2\",\"fr\":30},{\"nm\":\"\",\"mn\":\"\",\"layers\":[{\"ty\":4,\"nm\":\"pop\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.3,\"y\":1},\"s\":[5,5,100],\"t\":50},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[0,0,100],\"t\":100}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,1140,0],\"t\":31},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,260,0],\"t\":80}],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.251,0.8392,0.2706],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":1}],\"id\":\"comp_3\",\"fr\":30},{\"nm\":\"\",\"mn\":\"\",\"layers\":[{\"ty\":4,\"nm\":\"pop\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.3,\"y\":1},\"s\":[5,5,100],\"t\":50},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[0,0,100],\"t\":100}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,1140,0],\"t\":31},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,260,0],\"t\":80}],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.251,0.8392,0.2706],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":1}],\"id\":\"comp_4\",\"fr\":30},{\"nm\":\"\",\"mn\":\"\",\"layers\":[{\"ty\":4,\"nm\":\"pop\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.3,\"y\":1},\"s\":[5,5,100],\"t\":50},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[0,0,100],\"t\":100}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,1140,0],\"t\":31},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,260,0],\"t\":80}],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.251,0.8392,0.2706],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":1}],\"id\":\"comp_5\",\"fr\":30},{\"nm\":\"\",\"mn\":\"\",\"layers\":[{\"ty\":4,\"nm\":\"pop\",\"mn\":\"\",\"sr\":1,\"st\":0,\"op\":1800,\"ip\":0,\"hd\":false,\"cl\":\"\",\"ln\":\"\",\"ddd\":0,\"bm\":0,\"hasMask\":false,\"ao\":0,\"ks\":{\"a\":{\"a\":0,\"k\":[0,0,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.4,\"y\":0},\"i\":{\"x\":0.3,\"y\":1},\"s\":[5,5,100],\"t\":50},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[0,0,100],\"t\":100}],\"ix\":6},\"sk\":{\"a\":0,\"k\":0},\"p\":{\"a\":1,\"k\":[{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,1140,0],\"t\":31},{\"o\":{\"x\":0.167,\"y\":0.167},\"i\":{\"x\":0.833,\"y\":0.833},\"s\":[1504,260,0],\"t\":80}],\"ix\":2},\"sa\":{\"a\":0,\"k\":0},\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10}},\"ef\":[],\"shapes\":[{\"ty\":\"gr\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Group\",\"nm\":\"Ellipse 1\",\"ix\":1,\"cix\":2,\"np\":3,\"it\":[{\"ty\":\"el\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Shape - Ellipse\",\"nm\":\"Ellipse Path 1\",\"d\":1,\"p\":{\"a\":0,\"k\":[0,0],\"ix\":3},\"s\":{\"a\":0,\"k\":[3000,3000],\"ix\":2}},{\"ty\":\"fl\",\"bm\":0,\"cl\":\"\",\"ln\":\"\",\"hd\":false,\"mn\":\"ADBE Vector Graphic - Fill\",\"nm\":\"Fill 1\",\"c\":{\"a\":0,\"k\":[0.251,0.8392,0.2706],\"ix\":4},\"r\":1,\"o\":{\"a\":0,\"k\":100,\"ix\":5}},{\"ty\":\"tr\",\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"o\":{\"a\":0,\"k\":100,\"ix\":7}}]}],\"ind\":1}],\"id\":\"comp_6\",\"fr\":30}]}"));}}),
"[project]/src/config/constants.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "COMPANY_INFO": (()=>COMPANY_INFO),
    "DOMAIN": (()=>DOMAIN)
});
const COMPANY_INFO = {
    name: "Visegu",
    phone: "(510) 719-1444",
    email: "percyruiz@visegu.com",
    website: "www.visegu.com",
    address: "16198 Via Arriba San Lorezo, CA 94585"
};
const DOMAIN = "https://ronny998909-001-site1.qtempurl.com/";
}}),
"[project]/src/features/orders/inspections/components/typeQuest/AnswerSign.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$Loading$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/components/shared/Loading.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$stores$2f$useAuthStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/stores/useAuthStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/utils/axiosInstance.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
const AnswerSign = ({ onComplete })=>{
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [dataUser, setDataUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const user = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$stores$2f$useAuthStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAuthStore"])((state)=>state.user);
    const token = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$stores$2f$useAuthStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAuthStore"])((state)=>state.token);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchUser = async ()=>{
            try {
                setLoading(true);
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].get(`/User/GetUserId?UserId=${user?.userId}`);
                const data = res.data;
                setDataUser(data);
            } catch (error) {
                console.error("Error al cargar usuario:", error);
            } finally{
                setLoading(false);
            }
        };
        if (user?.userId) fetchUser();
    }, [
        user?.userId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (dataUser?.signatureImagePath) {
            onComplete(true, `${dataUser.signatureImagePath}`);
        } else {
            onComplete(false, undefined);
        }
    }, [
        dataUser?.signatureImagePath
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mt-6",
        children: dataUser?.signatureImagePath ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DOMAIN"]}${dataUser.signatureImagePath}`,
            alt: "Firma",
            className: "mx-auto bg-contain max-w-[500px] h-auto w-full"
        }, void 0, false, {
            fileName: "[project]/src/features/orders/inspections/components/typeQuest/AnswerSign.tsx",
            lineNumber: 58,
            columnNumber: 9
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$Loading$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                className: "mx-auto bg-contain max-w-[500px] h-auto my-10",
                label: ""
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/typeQuest/AnswerSign.tsx",
                lineNumber: 65,
                columnNumber: 11
            }, this)
        }, void 0, false)
    }, void 0, false, {
        fileName: "[project]/src/features/orders/inspections/components/typeQuest/AnswerSign.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = AnswerSign;
}}),
"[project]/src/features/orders/inspections/components/typeQuest/AnswerText.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// components/AnswerText.tsx
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const AnswerText = ({ value, onChange })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mt-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
            className: "textarea textarea-bordered w-full text-lg",
            placeholder: "Escribe tu respuesta...",
            value: value,
            onChange: (e)=>onChange(e.target.value)
        }, void 0, false, {
            fileName: "[project]/src/features/orders/inspections/components/typeQuest/AnswerText.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/features/orders/inspections/components/typeQuest/AnswerText.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = AnswerText;
}}),
"[project]/src/features/orders/inspections/components/typeQuest/AnswerOptions.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// components/AnswerOptions.tsx
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const AnswerOptions = ({ answers, renderAnswer })=>{
    console.log("datita: ", answers, renderAnswer);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mt-4 flex flex-row gap-4 flex-nowrap overflow-x-auto",
        children: answers.map((answer)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center",
                children: renderAnswer(answer, 0)
            }, answer.typeInspectionDetailAnswerId, false, {
                fileName: "[project]/src/features/orders/inspections/components/typeQuest/AnswerOptions.tsx",
                lineNumber: 15,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/features/orders/inspections/components/typeQuest/AnswerOptions.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = AnswerOptions;
}}),
"[project]/src/features/orders/inspections/components/GenerateStep3.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
//  Versión corregida: guarda todas las respuestas seleccionadas por nivel correctamente y respeta subAnswers anidados
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/store/inspection/inspectionFullStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/utils/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$Wizard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/Wizard.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$ModalUsingItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/ModalUsingItem.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$go$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/go/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/models/workOrder.types.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lottie$2d$react$2f$build$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/lottie-react/build/index.es.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lottie$2d$react$2f$build$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/lottie-react/build/index.es.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$lotties$2f$check$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/assets/lotties/check.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$typeQuest$2f$AnswerSign$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/typeQuest/AnswerSign.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$typeQuest$2f$AnswerText$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/typeQuest/AnswerText.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$typeQuest$2f$AnswerOptions$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/typeQuest/AnswerOptions.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const GenerateStep3 = ()=>{
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("inspections");
    const tToasts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("toast");
    const { fullInspection, groupName, groupId, titleQuestion, fullQuestion } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"])();
    const [selectedTree, setSelectedTree] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isSignValid, setIsSignValid] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [signUrl, setSignUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(undefined);
    const [showItemModal, setShowItemModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [modalAnswer, setModalAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [initialItems, setInitialItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [textResponse, setTextResponse] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const { resetTrigger } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"])();
    const [showRootPicker, setShowRootPicker] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedRootId, setSelectedRootId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setSelectedTree([]);
        setTextResponse("");
        setSignUrl(undefined);
        setIsSignValid(false);
    }, [
        resetTrigger
    ]);
    const originalRoots = fullQuestion?.originalAnswers ?? [];
    const currentAnswers = fullQuestion?.originalAnswers ?? fullQuestion?.answers ?? [];
    const isSingle = fullQuestion?.typeQuestion === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TypeQuestion"].SingleChoice;
    const isMultiple = fullQuestion?.typeQuestion === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TypeQuestion"].MultipleChoice;
    const isText = fullQuestion?.typeQuestion === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TypeQuestion"].TextInput;
    const isSign = fullQuestion?.typeQuestion === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TypeQuestion"].Sign;
    const openItemModal2 = (answer)=>{
        const findAnswerInTree = (tree)=>{
            for (const node of tree){
                if (node.typeInspectionDetailAnswerId === answer.typeInspectionDetailAnswerId) {
                    return node;
                }
                if (node.subAnswers?.length) {
                    const found = findAnswerInTree(node.subAnswers);
                    if (found) return found;
                }
            }
            return null;
        };
        const nodeInTree = findAnswerInTree(selectedTree);
        setModalAnswer(answer);
        setInitialItems(nodeInTree?.selectedItems ?? []);
        setShowItemModal(true);
    };
    const openItemModal = (answer)=>{
        const answerId = String(answer.typeInspectionDetailAnswerId);
        const selected = isSelected(answerId, selectedTree);
        if (!selected) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(`${tToasts("error")}: ${tToasts("msj.30")}`);
            return;
        }
        const findAnswerInTree = (tree)=>{
            for (const node of tree){
                if (String(node.typeInspectionDetailAnswerId) === answerId) return node;
                if (node.subAnswers?.length) {
                    const found = findAnswerInTree(node.subAnswers);
                    if (found) return found;
                }
            }
            return null;
        };
        const nodeInTree = findAnswerInTree(selectedTree);
        setModalAnswer(answer);
        setInitialItems(nodeInTree?.selectedItems ?? []);
        setShowItemModal(true);
    };
    const toggleAnswer = (tree, answer, parentId)=>{
        const isRoot = !parentId;
        //  SINGLE CHOICE: Solo 1 rama
        if (!isMultiple) {
            if (isRoot) {
                return [
                    {
                        ...answer,
                        subAnswers: []
                    }
                ];
            }
            // Solo permite una subrespuesta por nivel
            return tree.map((node)=>{
                if (String(node.typeInspectionDetailAnswerId) === parentId) {
                    return {
                        ...node,
                        subAnswers: [
                            {
                                ...answer,
                                subAnswers: []
                            }
                        ]
                    };
                }
                if (node.subAnswers?.length) {
                    return {
                        ...node,
                        subAnswers: toggleAnswer(node.subAnswers, answer, parentId)
                    };
                }
                return node;
            });
        }
        //  MULTIPLE CHOICE: una raíz + múltiples ramas
        if (isMultiple) {
            if (isRoot) {
                const exists = tree.find((a)=>a.typeInspectionDetailAnswerId === answer.typeInspectionDetailAnswerId);
                if (exists) {
                    return tree.filter((a)=>a.typeInspectionDetailAnswerId !== answer.typeInspectionDetailAnswerId);
                } else {
                    // Si ya hay otra raíz, la reemplaza (solo 1 raíz)
                    return [
                        {
                            ...answer,
                            subAnswers: []
                        }
                    ];
                }
            }
            // Para subniveles, sí permite múltiples
            return tree.map((node)=>{
                if (String(node.typeInspectionDetailAnswerId) === parentId) {
                    const exists = node.subAnswers?.some((sub)=>sub.typeInspectionDetailAnswerId === answer.typeInspectionDetailAnswerId);
                    const newSubs = exists ? node.subAnswers.filter((sub)=>sub.typeInspectionDetailAnswerId !== answer.typeInspectionDetailAnswerId) : [
                        ...node.subAnswers ?? [],
                        {
                            ...answer,
                            subAnswers: []
                        }
                    ];
                    return {
                        ...node,
                        subAnswers: newSubs
                    };
                }
                if (node.subAnswers?.length) {
                    return {
                        ...node,
                        subAnswers: toggleAnswer(node.subAnswers, answer, parentId)
                    };
                }
                return node;
            });
        }
        return tree;
    };
    const getAnswerFromTree = (tree, id)=>{
        for (const a of tree){
            if (String(a.typeInspectionDetailAnswerId) === id) return a;
            if (a.subAnswers?.length) {
                const found = getAnswerFromTree(a.subAnswers, id);
                if (found) return found;
            }
        }
        return undefined;
    };
    const hasRootWithChildren = (tree)=>{
        return tree.some((a)=>a.subAnswers?.length);
    };
    const isSelected = (id, tree)=>{
        for (const a of tree){
            if (String(a.typeInspectionDetailAnswerId) === id) return true;
            if (a.subAnswers?.length && isSelected(id, a.subAnswers)) return true;
        }
        return false;
    };
    const updateSelectedItems = (tree, answerId, items)=>{
        return tree.map((a)=>{
            if (String(a.typeInspectionDetailAnswerId) === answerId) {
                return {
                    ...a,
                    selectedItems: items
                };
            }
            if (a.subAnswers?.length) {
                return {
                    ...a,
                    subAnswers: updateSelectedItems(a.subAnswers, answerId, items)
                };
            }
            return a;
        });
    };
    const renderAnswerRecursive = (answer, level = 0, parentId)=>{
        const backgroundColor = answer.color === "#ffffff" ? "#171717" : answer.color;
        const isLight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isColorLight"])(backgroundColor);
        const textColor = isLight ? "#000000" : "#ffffff";
        const selected = isSelected(String(answer.typeInspectionDetailAnswerId), selectedTree);
        const treeAnswer = getAnswerFromTree(selectedTree, String(answer.typeInspectionDetailAnswerId));
        const hasItems = treeAnswer?.selectedItems?.length && treeAnswer.selectedItems.length > 0;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center relative",
                children: [
                    level > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-[-16px] h-4 w-px bg-gray-300"
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                        lineNumber: 276,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-row items-center justify-start my-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-row items-center gap-0 cursor-pointer group",
                                onClick: ()=>{
                                    const updated = toggleAnswer(selectedTree, answer, parentId);
                                    setSelectedTree(updated);
                                    // ✅ Solo aplica si estamos seleccionando raíz
                                    const isRoot = !parentId;
                                    if (isRoot && (isSingle || isMultiple) && updated.length === 1 && // solo hay 1 respuesta raíz
                                    isLastQuestionInGroup // última pregunta del grupo
                                    ) {
                                        completeCurrentQuestion(updated[0].response); // llama directamente
                                    }
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "data-color": answer.color,
                                    style: {
                                        backgroundColor,
                                        color: textColor
                                    },
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(!answer.usingItem ? "overflow-hidden rounded-tl-full rounded-full px-5 flex flex-row transition-all group-hover:shadow-lg" : "overflow-hidden rounded-tl-full rounded-bl-full px-5 flex flex-row transition-all group-hover:shadow-lg"),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-[45px] flex items-center justify-center pr-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: isMultiple ? "checkbox" : "radio",
                                                name: `select-answer-${level}-${parentId ?? "root"}`,
                                                checked: selected,
                                                readOnly: true,
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(isMultiple ? "checkbox bg-white checked:bg-white checked:text-green-600 checked:border-green-500" : "radio bg-white checked:bg-white checked:text-green-600 checked:border-green-500")
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                                lineNumber: 309,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                            lineNumber: 308,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-row items-center justify-center min-w-auto h-[45px] overflow-hidden",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "truncate",
                                                children: answer.response
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                                lineNumber: 322,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                            lineNumber: 321,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                    lineNumber: 299,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 280,
                                columnNumber: 13
                            }, this),
                            answer.usingItem && (!hasItems ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    openItemModal(answer);
                                },
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("h-full cursor-pointer flex items-center rounded-tr-full rounded-br-full justify-center px-3 min-w-[45px] overflow-hidden bg-[#35353382]"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$go$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GoChecklist"], {
                                    className: "size-7 text-black/50 transition-all hover:text-black"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                    lineNumber: 338,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 329,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    openItemModal(answer);
                                },
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("h-full cursor-pointer flex items-center rounded-tr-full rounded-br-full justify-center px-3 min-w-[45px] overflow-hidden bg-green-300"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lottie$2d$react$2f$build$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"], {
                                    animationData: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$lotties$2f$check$2e$json__$28$json$29$__["default"],
                                    style: {
                                        width: 35,
                                        height: 35
                                    },
                                    loop: false
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                    lineNumber: 350,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 341,
                                columnNumber: 17
                            }, this)),
                            selected && answer.selectedItems && answer.selectedItems.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs text-center mt-1 text-gray-500",
                                children: [
                                    answer.selectedItems.length,
                                    " ítem",
                                    answer.selectedItems.length > 1 ? "s" : "",
                                    " agregado",
                                    answer.selectedItems.length > 1 ? "s" : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 362,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                        lineNumber: 279,
                        columnNumber: 11
                    }, this),
                    answer.subAnswers?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("mt-4 flex flex-row gap-4 pt-4", selected ? "border-t border-black/10" : "opacity-40 pointer-events-none"),
                        children: answer.subAnswers.map((sub)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col items-center",
                                children: renderAnswerRecursive(sub, level + 1, String(answer.typeInspectionDetailAnswerId))
                            }, sub.typeInspectionDetailAnswerId, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 380,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                        lineNumber: 371,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                lineNumber: 274,
                columnNumber: 9
            }, this)
        }, answer.typeInspectionDetailAnswerId, false, {
            fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
            lineNumber: 270,
            columnNumber: 7
        }, this);
    };
    const exportTree = (answers)=>{
        return answers.map((a)=>({
                response: a.response,
                usingItem: a.usingItem,
                selectedItems: a.selectedItems ?? [],
                subAnswers: a.subAnswers?.length ? exportTree(a.subAnswers) : []
            }));
    };
    const completeSign = ()=>{
        const store = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState();
        const current = store.fullInspection;
        const fullQuestion = store.fullQuestion;
        if (!current || !fullQuestion) {
            console.warn("❌ Datos incompletos, no se puede continuar.");
            return;
        }
        const updatedQuestions = current.questions.map((q)=>{
            const match = q.typeInspectionDetailId === fullQuestion.typeInspectionDetailId;
            if (match) {
                return {
                    ...q,
                    statusInspectionConfig: true
                };
            }
            return q;
        });
        store.setFullInspection({
            ...current,
            questions: updatedQuestions
        });
        store.setStepWizard(2); // ← vuelve al paso 2
    };
    const completeCurrentQuestionWithRoot = (rootLabel)=>{
        const store = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState();
        const current = store.fullInspection;
        const fullQuestion = store.fullQuestion;
        if (!current || !fullQuestion) return;
        // Actualiza SOLO la pregunta actual con el rootLabel elegido en el modal
        const updatedQuestions = current.questions.map((q)=>{
            if (q.typeInspectionDetailId === fullQuestion.typeInspectionDetailId) {
                return {
                    ...q,
                    finalResponse: rootLabel,
                    statusInspectionConfig: true,
                    answers: selectedTree.length > 0 ? selectedTree : q.answers
                };
            }
            return q;
        });
        // Conjunto de preguntas del MISMO grupo (para decidir siguiente)
        const currentGroupQuestions = updatedQuestions.filter((q)=>q.groupId === fullQuestion.groupId && q.groupName === fullQuestion.groupName);
        const groupCompleted = currentGroupQuestions.every((q)=>q.statusInspectionConfig);
        // Persistimos TODO el estado de la inspección
        const updatedInspection = {
            ...current,
            questions: updatedQuestions,
            statusInspectionConfig: updatedQuestions.every((q)=>q.statusInspectionConfig)
        };
        store.setFullInspection(updatedInspection);
        // Cierra el modal SIEMPRE
        setShowRootPicker(false);
        // Si el grupo NO terminó, navega a la siguiente sin responder del mismo grupo
        if (!groupCompleted) {
            const nextUnanswered = currentGroupQuestions.find((q)=>!q.statusInspectionConfig);
            if (nextUnanswered) {
                store.setFullQuestion(nextUnanswered);
                store.setGroupId(nextUnanswered.groupId);
                store.setGroupName(nextUnanswered.groupName);
                store.setTitleQuestion(nextUnanswered.question);
                store.setStepWizard(3); // 👉 pasa directo a la siguiente pregunta
                return;
            }
        }
        // Si ya no quedan preguntas en este grupo, regresa al listado
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(`${tToasts("ok")}: ${tToasts("msj.31")}`);
        store.setStepWizard(2);
    };
    const completeCurrentQuestion = (responseValue = null)=>{
        const store = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState();
        const current = store.fullInspection;
        const fullQuestion = store.fullQuestion;
        if (!current || !fullQuestion) return;
        let resolvedFinalResponse = responseValue ?? "";
        // 🟢 Si es SingleChoice, obtener el texto de la raíz seleccionada
        if (isSingle && selectedTree.length === 1) {
            resolvedFinalResponse = selectedTree[0].response;
        }
        const updatedQuestions = current.questions.map((q)=>{
            if (q.typeInspectionDetailId === fullQuestion.typeInspectionDetailId) {
                return {
                    ...q,
                    finalResponse: resolvedFinalResponse,
                    statusInspectionConfig: true,
                    answers: selectedTree.length > 0 ? selectedTree : q.answers
                };
            }
            return q;
        });
        const currentGroupQuestions = updatedQuestions.filter((q)=>q.groupId === fullQuestion.groupId && q.groupName === fullQuestion.groupName);
        const groupCompleted = currentGroupQuestions.every((q)=>q.statusInspectionConfig);
        const updatedInspection = {
            ...current,
            questions: updatedQuestions,
            statusInspectionConfig: updatedQuestions.every((q)=>q.statusInspectionConfig)
        };
        store.setFullInspection(updatedInspection);
        if (!groupCompleted) {
            const nextUnanswered = currentGroupQuestions.find((q)=>!q.statusInspectionConfig);
            if (nextUnanswered) {
                store.setFullQuestion(nextUnanswered);
                store.setGroupId(nextUnanswered.groupId);
                store.setGroupName(nextUnanswered.groupName);
                store.setTitleQuestion(nextUnanswered.question);
                store.setStepWizard(3);
                return;
            }
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(`${tToasts("ok")}: ${tToasts("msj.31")}`);
        store.setStepWizard(2);
    };
    const isLastQuestionInGroup = fullInspection?.questions.filter((q)=>q.groupId === fullQuestion?.groupId && q.groupName === fullQuestion?.groupName).every((q)=>q.statusInspectionConfig || q.typeInspectionDetailId === fullQuestion?.typeInspectionDetailId);
    const isAnswerInSelectedTree = (id, tree)=>{
        for (const node of tree){
            if (node.typeInspectionDetailAnswerId === id) return true;
            if (node.subAnswers && node.subAnswers.length > 0) {
                if (isAnswerInSelectedTree(id, node.subAnswers)) return true;
            }
        }
        return false;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
    /*  console.log("📡 TREE RESPUESTAS EN TIEMPO REAL:", exportTree(selectedTree));*/ }, [
        selectedTree
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!fullQuestion || !fullInspection) return;
        const q = fullInspection.questions.find((q)=>q.typeInspectionDetailId === fullQuestion.typeInspectionDetailId);
        // Siempre hidrata originalAnswers
        if (q && !q.originalAnswers && fullQuestion.answers) {
            q.originalAnswers = structuredClone(fullQuestion.answers);
        }
        if (q?.originalAnswers) {
            fullQuestion.originalAnswers = q.originalAnswers;
        }
        const alreadyAnswered = q?.statusInspectionConfig;
        if (alreadyAnswered && (isSingle || isMultiple)) {
            // ✅ Permite volver a editar cualquier SingleChoice o MultipleChoice
            setSelectedTree(q.answers ?? []);
            setTextResponse(q.finalResponse ?? "");
            setSignUrl(q.finalResponse ?? "");
            setIsSignValid(!!q.finalResponse);
        } else if (alreadyAnswered && isText) {
            // TextInput → mantener el texto sin editar
            setTextResponse(q.finalResponse ?? "");
        } else if (alreadyAnswered && isSign) {
            setSignUrl(q.finalResponse ?? "");
            setIsSignValid(!!q.finalResponse);
        } else {
            // Nueva pregunta
            setSelectedTree([]);
            setTextResponse("");
            setSignUrl("");
            setIsSignValid(false);
        }
    }, [
        fullQuestion?.typeInspectionDetailId
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$Wizard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                lineNumber: 631,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "card bg-base-200 p-6 shadow-xs",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col md:flex-row justify-between items-start md:items-center gap-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-bold order-2 md:order-1",
                                children: [
                                    t("step3.1"),
                                    " ",
                                    titleQuestion
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 634,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "rounded-full bg-red-400 order-1 md:order-2  md:flex items-center justify-center text-white overflow-hidden px-3 gap-1 py-1  md:min-w-fit flex-row flex",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IoIosInformationCircleOutline"], {
                                        className: "size-6"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                        lineNumber: 638,
                                        columnNumber: 13
                                    }, this),
                                    fullQuestion?.typeQuestion !== undefined ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TypeQuestionLabel"][fullQuestion.typeQuestion] : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 637,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                        lineNumber: 633,
                        columnNumber: 9
                    }, this),
                    isSign && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$typeQuest$2f$AnswerSign$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        onComplete: (valid, url)=>{
                            setIsSignValid(valid);
                            setSignUrl(url);
                            if (valid && isLastQuestionInGroup) {
                            //completeCurrentQuestion(url);
                            }
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                        lineNumber: 646,
                        columnNumber: 11
                    }, this),
                    isText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$typeQuest$2f$AnswerText$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        value: textResponse,
                        onChange: setTextResponse
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                        lineNumber: 659,
                        columnNumber: 11
                    }, this),
                    (isSingle || isMultiple) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$typeQuest$2f$AnswerOptions$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        answers: currentAnswers,
                        renderAnswer: renderAnswerRecursive
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                        lineNumber: 663,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center mt-6",
                        children: [
                            isText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                disabled: textResponse.length === 0,
                                className: "btn font-normal bg-black text-white rounded-full pr-3 py-6 sm:flex border-none flex-1 w-full md:w-[300px] mx-auto text-[13px]",
                                onClick: ()=>completeCurrentQuestion(textResponse),
                                children: isLastQuestionInGroup ? "Save" : "Continue"
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 671,
                                columnNumber: 13
                            }, this),
                            (isSingle || isMultiple) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                disabled: selectedTree.length === 0,
                                className: "btn font-normal bg-black text-white rounded-full pr-3 py-6 sm:flex border-none flex-1 w-full md:w-[300px] mx-auto text-[13px]",
                                onClick: ()=>{
                                    setShowRootPicker(true);
                                },
                                children: isLastQuestionInGroup ? "Save" : "Continue"
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 681,
                                columnNumber: 13
                            }, this),
                            isSign && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                disabled: !isSignValid,
                                className: "btn font-normal bg-black text-white rounded-full pr-3 py-6 sm:flex border-none flex-1 w-full md:w-[300px] mx-auto text-[13px]",
                                onClick: ()=>completeCurrentQuestion(signUrl),
                                children: isLastQuestionInGroup ? "Save" : "Continue"
                            }, void 0, false, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                lineNumber: 693,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                        lineNumber: 669,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                lineNumber: 632,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center mt-5 px-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "btn font-normal bg-red-300 text-white rounded-full pr-3 py-6 sm:flex border-none flex-1 w-full  md:max-w-[300px] mx-auto text-[13px] transition-all hover:bg-red-600",
                    onClick: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setStepWizard(2),
                    children: t("step3.2")
                }, void 0, false, {
                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                    lineNumber: 705,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                lineNumber: 704,
                columnNumber: 7
            }, this),
            showItemModal && modalAnswer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$ModalUsingItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                onClose: ()=>setShowItemModal(false),
                onSave: (items)=>{
                    if (!modalAnswer) return;
                    // 💡 Aseguramos usar siempre la última versión del árbol
                    setSelectedTree((prevTree)=>{
                        const updated = updateSelectedItems(prevTree, String(modalAnswer.typeInspectionDetailAnswerId), items);
                        console.log("✅ Árbol actualizado con items:", updated);
                        return updated;
                    });
                    setShowItemModal(false);
                },
                initialItems: initialItems
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                lineNumber: 714,
                columnNumber: 9
            }, this),
            showRootPicker && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 bg-black/40 flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white p-6 rounded-xl w-[90%] max-w-md relative",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between mb-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-xl font-bold ",
                                    children: t("step3.3")
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                    lineNumber: 740,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "bg-black text-white w-[38px] h-[38px] absolute right-0 top-0 rounded-bl-3xl flex items-center justify-center transition-all cursor-pointer",
                                    onClick: ()=>setShowRootPicker(!showRootPicker),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IoCloseOutline"], {
                                        className: "text-2xl font-bold"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                        lineNumber: 745,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                    lineNumber: 741,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                            lineNumber: 739,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-4",
                            children: (fullQuestion?.originalAnswers ?? []).map((root)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        setSelectedRootId(root.response);
                                        setShowRootPicker(false);
                                        completeCurrentQuestionWithRoot(root.response);
                                    },
                                    className: `btn w-full min-h-[39px] p-2 rounded-md text-lg hover:opacity-85`,
                                    style: {
                                        backgroundColor: root.color,
                                        color: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isColorLight"])(root.color) ? "#000" : "#fff"
                                    },
                                    children: root.response
                                }, root.typeInspectionDetailAnswerId, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                                    lineNumber: 750,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                            lineNumber: 748,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                    lineNumber: 738,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep3.tsx",
                lineNumber: 737,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = GenerateStep3;
}}),
"[project]/src/features/orders/inspections/components/GenerateStep4.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$Wizard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/Wizard.tsx [app-ssr] (ecmascript)");
;
;
const GenerateStep4 = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$Wizard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep4.tsx",
                lineNumber: 7,
                columnNumber: 7
            }, this),
            " ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "GenerateStep4"
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep4.tsx",
                lineNumber: 7,
                columnNumber: 18
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = GenerateStep4;
}}),
"[project]/src/features/orders/inspections/components/GenerateStep0.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/utils/axiosInstance.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/md/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash/debounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$Loading$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/components/shared/Loading.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/gi/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/store/inspection/inspectionFullStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep1$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/GenerateStep1.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep2$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/GenerateStep2.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep3$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/GenerateStep3.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep4$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/GenerateStep4.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const GenerateStep0 = ()=>{
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("inspections");
    const { fullInspection, groupName, stepWizard, resetFullInspection } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const [customerOptions, setCustomerOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedCustomer, setSelectedCustomer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showCustomerDropdown, setShowCustomerDropdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const inputCustomerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [typeOptions, setTypeOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedType, setSelectedType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoadingCustomer, setIsLoadingCustomer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [inspectionData, setInspectionData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [objFilterForm, setObjFilterForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        client: ""
    });
    // Búsqueda en tiempo real con debounce
    const debouncedSearchCustomer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async (value)=>{
        if (value.length >= 3) {
            try {
                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].get(`/QuickBooks/Customers/GetCustomerAll?search=${encodeURIComponent(value)}`);
                const filtered = (response.data ?? []).filter((item)=>item.name.toLowerCase().startsWith(value.toLowerCase()));
                setCustomerOptions(filtered);
                setShowCustomerDropdown(true);
            } catch (error) {
                console.error("Error buscando clientes:", error);
                setCustomerOptions([]);
            } finally{
                setIsLoadingCustomer(false);
            }
        } else {
            setCustomerOptions([]);
            setShowCustomerDropdown(false);
        }
    }, 500)).current;
    const handleCustomerChange = (e)=>{
        const value = e.target.value;
        setObjFilterForm({
            client: value
        });
        if (value.length >= 1) {
            setIsLoadingCustomer(true); // 🔥 Mostrar desde el primer caracter
        } else {
            setIsLoadingCustomer(false); // 🔕 Apagar si el campo queda vacío
        }
        debouncedSearchCustomer(value);
        // Si se borra el campo, reinicia todo
        if (!value.trim()) {
            resetFields();
        }
    };
    const handleCustomerSelect = (option)=>{
        setSelectedCustomer(option);
        setObjFilterForm({
            client: option.name
        });
        setShowCustomerDropdown(false);
        setCustomerOptions([]);
        // 🔄 Limpiar selección anterior
        setSelectedType(null);
        setInspectionData(null);
        setTypeOptions([]);
        // Cargar nuevos tipos
        fetchTypeInspections(option.id);
    };
    const fetchTypeInspections = async (customerId)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].get("/TypeInspection");
            const filtered = res.data.items.filter((item)=>item.customerId == customerId || item.customerId == "0");
            setTypeOptions(filtered);
        } catch (err) {
            console.error("Error cargando tipos de inspección", err);
        }
    };
    const handleTypeChange = async (e)=>{
        setInspectionData(null);
        const found = typeOptions.find((type)=>type.typeInspectionId === parseInt(e.target.value));
        setSelectedType(found ?? null);
        if (found) {
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].get(`/TypeInspection/GetFullTypeInspectionId?TypeInspectionId=${found.typeInspectionId}`);
                setInspectionData(res.data);
                console.log("Datos completos de inspección:", res.data);
            } catch (err) {
                console.error("Error al obtener datos completos de inspección", err);
            }
        } else {
            setInspectionData(null);
        }
    };
    const goStep = async (typeInspectionId, groupName, groupId)=>{
        try {
            setIsLoading(true);
            const store = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState();
            const previous = store.fullInspection;
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$axiosInstance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axiosInstance"].get(`/TypeInspection/GetFullTypeInspectionId?TypeInspectionId=${typeInspectionId}`);
            // fusiona respuestas anteriores si existen
            const mergedQuestions = res.data.questions.map((q)=>{
                const prev = previous?.questions.find((pq)=>pq.typeInspectionDetailId === q.typeInspectionDetailId);
                return {
                    ...q,
                    answers: prev?.answers ?? q.answers,
                    finalResponse: prev?.finalResponse ?? "",
                    statusInspectionConfig: prev?.statusInspectionConfig ?? false
                };
            });
            store.setFullInspection({
                ...res.data,
                questions: mergedQuestions
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setGroupName(groupName);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setGroupId(groupId);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$store$2f$inspection$2f$inspectionFullStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useInspectionFullStore"].getState().setStepWizard(1);
            setIsLoading(false);
        /* const grouped = res.data.questions.reduce((acc, question) => {
        if (!acc[question.groupName]) acc[question.groupName] = [];
        acc[question.groupName].push(question);
        return acc;
      }, {} as Record<string, IFullQuestion[]>);*/ //router.push(`${pathname}/configuration`);
        } catch (err) {
            console.error("Error al obtener datos completos de inspección", err);
        }
    };
    const resetFields = ()=>{
        setSelectedCustomer(null);
        setSelectedType(null);
        setTypeOptions([]);
        setInspectionData(null);
        setObjFilterForm({
            client: ""
        });
        if (inputCustomerRef.current) inputCustomerRef.current.value = "";
        setCustomerOptions([]);
        setShowCustomerDropdown(false);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (selectedCustomer && selectedType && inspectionData && inspectionData.questions.length > 0) {
            // Obtenemos el primer grupo (groupName y groupId)
            const firstGroup = inspectionData.questions[0];
            if (firstGroup) {
                goStep(inspectionData.typeInspectionId, firstGroup.groupName, firstGroup.groupId);
            }
        }
    }, [
        selectedCustomer,
        selectedType,
        inspectionData
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
                className: "fieldset bg-base-200 border-base-300 rounded-box w-full border p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                        className: "fieldset-legend text-lg",
                        children: t("step0.1")
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                        lineNumber: 231,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                                        className: "fieldset-legend text-lg font-normal",
                                        children: t("step0.2")
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                        lineNumber: 235,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "text",
                                                        className: "input input-lg text-lg w-full",
                                                        name: "customer_order",
                                                        value: objFilterForm.client,
                                                        onChange: handleCustomerChange,
                                                        ref: inputCustomerRef,
                                                        autoComplete: "off"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                        lineNumber: 240,
                                                        columnNumber: 17
                                                    }, this),
                                                    isLoadingCustomer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "absolute right-3 top-1/2 -translate-y-1/2 z-20",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$Loading$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                            height: "h-[39px]",
                                                            enableLabel: false,
                                                            size: "loading-sm "
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                            lineNumber: 251,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                        lineNumber: 250,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                lineNumber: 239,
                                                columnNumber: 15
                                            }, this),
                                            showCustomerDropdown && customerOptions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "bg-base-100 w-full rounded-box shadow-md z-50 max-h-60 overflow-y-auto relative",
                                                children: customerOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        className: "cursor-pointer text-sm",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            className: "block w-full text-left px-4 py-2 hover:bg-gray-100",
                                                            onClick: ()=>handleCustomerSelect(option),
                                                            children: option.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                            lineNumber: 263,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, option.id, false, {
                                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                        lineNumber: 262,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                lineNumber: 260,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                        lineNumber: 238,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                lineNumber: 234,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                                        className: "fieldset-legend text-lg font-normal",
                                        children: t("step0.3")
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                        lineNumber: 279,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        className: "select w-full text-lg input-lg disabled:border-gray-200",
                                        disabled: !typeOptions.length,
                                        value: selectedType?.typeInspectionId || "",
                                        onChange: handleTypeChange,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "",
                                                children: t("step0.4")
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                lineNumber: 288,
                                                columnNumber: 15
                                            }, this),
                                            typeOptions.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: type.typeInspectionId,
                                                    children: type.name
                                                }, type.typeInspectionId, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                    lineNumber: 290,
                                                    columnNumber: 17
                                                }, this))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                        lineNumber: 282,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                lineNumber: 278,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col !hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                                        className: "fieldset-legend text-lg font-normal hidden md:flex min-h-[32px]",
                                        children: " "
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                        lineNumber: 302,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-row items-center justify-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "btn bg-black rounded-full pr-3 py-6 sm:flex border-none flex-1",
                                                onClick: ()=>console.log({
                                                        selectedCustomer,
                                                        selectedType
                                                    }),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IoSearchOutline"], {
                                                        className: "text-xl text-white"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                        lineNumber: 310,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "py-1 px-4 text-white font-normal rounded-full md:block text-[13px]",
                                                        children: "Search"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                        lineNumber: 311,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                lineNumber: 306,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "btn bg-black/50 rounded-full pr-3 py-6 sm:flex border-none w-[50px]",
                                                onClick: resetFields,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MdOutlineSettingsBackupRestore"], {
                                                    className: "text-2xl text-white"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                    lineNumber: 319,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                lineNumber: 315,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                        lineNumber: 305,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                lineNumber: 301,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                        lineNumber: 232,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                lineNumber: 230,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "!hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "cont my-5 flex flex-col gap-1",
                    children: inspectionData && Object.entries(inspectionData.questions.reduce((acc, question)=>{
                        if (!acc[question.groupName]) acc[question.groupName] = [];
                        acc[question.groupName].push(question);
                        return acc;
                    }, {})).map(([groupName, questions])=>{
                        const groupId = questions[0]?.groupId;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>goStep(inspectionData.typeInspectionId, groupName, groupId),
                            className: "w-full card lg:card-side bg-black/80 shadow-sm overflow-hidden cursor-pointer transition-all hover:shadow-lg  hover:bg-[#191917] text-white hover:text-white/80 flex flex-row",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-[#191917] w-fit flex items-center justify-center p-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GiAutoRepair"], {
                                        className: "w-[25px] h-[25px]  text-white"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                        lineNumber: 353,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                    lineNumber: 352,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "card-body flex flex-row justify-between gap-5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col items-start",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "card-title text-left",
                                                    children: [
                                                        groupName,
                                                        " "
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                    lineNumber: 357,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-lg text-left",
                                                    children: inspectionData.description
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                    lineNumber: 358,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                            lineNumber: 356,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "card-actions justify-end flex items-center ",
                                            children: [
                                                questions.filter((item)=>item.status === 0).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "badge badge-error text-white text-lg",
                                                    children: questions.filter((item)=>item.status === 0).length
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 25
                                                }, this),
                                                questions.filter((item)=>item.status === 1).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "badge badge-success text-white text-lg",
                                                    children: questions.filter((item)=>item.status === 1).length
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                                    lineNumber: 371,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                            lineNumber: 362,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                                    lineNumber: 355,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, groupName, true, {
                            fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                            lineNumber: 345,
                            columnNumber: 17
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                    lineNumber: 331,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                lineNumber: 326,
                columnNumber: 7
            }, this),
            inspectionData && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "containerX mt-12 max-w-full mb-5",
                children: [
                    objFilterForm.client !== "" && stepWizard === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep1$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        ClientName: objFilterForm.client
                    }, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                        lineNumber: 385,
                        columnNumber: 13
                    }, this),
                    stepWizard === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep2$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                        lineNumber: 387,
                        columnNumber: 32
                    }, this),
                    stepWizard === 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep3$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                        lineNumber: 388,
                        columnNumber: 32
                    }, this),
                    stepWizard === 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep4$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                        lineNumber: 389,
                        columnNumber: 32
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/orders/inspections/components/GenerateStep0.tsx",
                lineNumber: 383,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = GenerateStep0;
}}),
"[project]/src/shared/hooks/usePageTitle.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "usePageTitle": (()=>usePageTitle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$utils$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/utils.tsx [app-ssr] (ecmascript)");
;
;
;
const usePageTitle = ()=>{
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const [pageTitle, setPageTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (pathname) {
            const title = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$utils$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLastPathSegmentFormatted"])(pathname);
            setPageTitle(title);
        }
    }, [
        pathname
    ]);
    return pageTitle;
};
}}),
"[project]/src/shared/components/shared/BackButton.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$hooks$2f$usePageTitle$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/hooks/usePageTitle.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const BackButton = ({ title, disableArrow = false, link })=>{
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const pageTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$hooks$2f$usePageTitle$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePageTitle"])();
    const [parentPath, setParentPath] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const segments = pathname.split("/").filter(Boolean);
        const dashboardIndex = segments.findIndex((s)=>s === "dashboard");
        if (dashboardIndex === -1 || segments.length <= dashboardIndex + 1) {
            setParentPath(null);
        } else {
            const newPath = "/" + segments.slice(0, segments.length - 1).join("/");
            setParentPath(newPath);
        }
    }, [
        pathname
    ]);
    const handleBack = ()=>{
        if (link) {
            router.push(link);
        } else {
            if (parentPath) {
                router.push(parentPath);
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-row gap-4 items-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "font-bold text-xl md:text-2xl lg:text-3xl gap-2 flex flex-row items-center justify-start",
            children: [
                !disableArrow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: handleBack,
                    className: "btn btn-sm",
                    children: "←"
                }, void 0, false, {
                    fileName: "[project]/src/shared/components/shared/BackButton.tsx",
                    lineNumber: 48,
                    columnNumber: 11
                }, this),
                title || (pageTitle ? pageTitle : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "skeleton h-6 w-48 rounded"
                }, void 0, false, {
                    fileName: "[project]/src/shared/components/shared/BackButton.tsx",
                    lineNumber: 56,
                    columnNumber: 13
                }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/src/shared/components/shared/BackButton.tsx",
            lineNumber: 46,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/shared/components/shared/BackButton.tsx",
        lineNumber: 45,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = BackButton;
}}),
"[project]/src/app/[locale]/dashboard/orders/inspections/create/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep0$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/inspections/components/GenerateStep0.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$BackButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/components/shared/BackButton.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
const Page = ()=>{
    const tAside = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("aside");
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    const id = typeof params.id === "string" ? params.id : "";
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const changeTitle = (newTitle)=>{
        setTitle(newTitle);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "header-page flex flex-row items-center justify-between min-h-[70px] bg-base-200 px-6 gap-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$components$2f$shared$2f$BackButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    title: tAside("module0.inspections")
                }, void 0, false, {
                    fileName: "[project]/src/app/[locale]/dashboard/orders/inspections/create/page.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/dashboard/orders/inspections/create/page.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "body-app overflow-y-auto pt-[20px]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container max-w-full mb-5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$inspections$2f$components$2f$GenerateStep0$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/app/[locale]/dashboard/orders/inspections/create/page.tsx",
                        lineNumber: 30,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/[locale]/dashboard/orders/inspections/create/page.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/dashboard/orders/inspections/create/page.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = Page;
}}),

};

//# sourceMappingURL=src_8cb481dd._.js.map