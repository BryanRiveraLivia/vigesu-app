(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/orders/models/workOrder.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
;
;
const MckinneyFederalInspection = ({ data, inspectionDetails, isEditable })=>{
    console.log("data: ", data);
    console.log("inspectionDetails: ", inspectionDetails);
    const getAnswerValue = (templateQuestionId)=>{
        const match = inspectionDetails ? inspectionDetails.find((item)=>Number(item.templateInspectionQuestionId) === Number(templateQuestionId)) : null;
        if (!match) {
            console.warn(`❌ Sin match para QuestionId: ${templateQuestionId}`);
            return "";
        }
        const typeQuestion = data?.templateInspectionQuestions.find((item)=>item.templateInspectionQuestionId === Number(templateQuestionId))?.typeQuestion;
        if (!typeQuestion) {
            console.warn(`❌ Sin match para typeQuestion: ${templateQuestionId}`);
            return "";
        }
        let value = "";
        switch(typeQuestion){
            case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TypeQuestion"].TextInput:
                // ✅ Caso texto libre
                value = match.finalResponse?.trim() ?? "";
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TypeQuestion"].MultipleChoice:
                // ✅ Caso múltiple: aseguramos que inspeccionDetailAnswers tenga data
                if (Array.isArray(match.inspectionDetailAnswers) && match.inspectionDetailAnswers.length > 0) {
                    value = match.inspectionDetailAnswers.map((ans)=>ans.response?.trim()).filter(Boolean).join(", ");
                }
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TypeQuestion"].SingleChoice:
                // ✅ Caso selección única: usar primera respuesta válida
                if (Array.isArray(match.inspectionDetailAnswers) && match.inspectionDetailAnswers.length > 0) {
                    value = match.inspectionDetailAnswers[0]?.response?.trim() ?? "";
                }
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$orders$2f$models$2f$workOrder$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TypeQuestion"].Sign:
                value = match.finalResponse?.trim() ?? "";
                break;
            default:
                value = match.finalResponse?.trim() ?? "";
        }
        console.log(`🔎 [MATCH] QID:${templateQuestionId} | Type:${typeQuestion} | FinalResponse:"${match.finalResponse}" | Answers:[${match.inspectionDetailAnswers?.map((a)=>a.response)}] | Value:"${value}"`);
        return value || "";
    };
    const render = (details, templateQuestionId)=>{
        if (!Array.isArray(details)) return {
            left: null,
            right: null
        };
        const detail = details.find((d)=>Number(d.templateInspectionQuestionId) === Number(templateQuestionId));
        if (!detail) return {
            left: null,
            right: null
        };
        const final = detail.finalResponse?.trim().toUpperCase() ?? "";
        const answers = detail.inspectionDetailAnswers ?? [];
        const hasR = answers.some((a)=>a.response?.trim().toUpperCase() === "R");
        // Caso 1: Final = R
        if (final === "R") return {
            left: null,
            right: "R"
        };
        // Caso 2: Final OK/X/NA sin R
        if ([
            "OK",
            "CHECK",
            "X",
            "NA"
        ].includes(final) && !hasR) {
            return {
                left: final === "OK" ? "✔" : final,
                right: null
            };
        }
        // Caso 3: Final distinto de R y hay R
        if (final && hasR) return {
            left: final,
            right: "R"
        };
        // Caso 4: No hay final válido
        if (answers.length > 0) {
            if (hasR) return {
                left: final || answers[0].response || null,
                right: "R"
            };
            return {
                left: final || answers[0].response || null,
                right: null
            };
        }
        return {
            left: null,
            right: null
        };
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: "w-full  border-collapse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                className: "border",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "p-2 text-center gap-2 w-[16.66%]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "truncate",
                                                children: "Unit #"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 165,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-normal truncate ml-2",
                                                children: getAnswerValue(1)
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 166,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 164,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "p-2 text-center gap-2 w-[16.66%]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "truncate",
                                                children: "VIN #"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 171,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-normal truncate ml-2",
                                                children: getAnswerValue(2)
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 172,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 170,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "p-2 text-center gap-2 w-[16.66%]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "t",
                                                children: "Make"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 177,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-normal truncate ml-2",
                                                children: getAnswerValue(3)
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 178,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 176,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "p-2 text-center gap-2 w-[16.66%]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "truncate",
                                                children: "Year"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 183,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-normal truncate ml-2",
                                                children: getAnswerValue(4)
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 184,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 182,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "p-2 text-center gap-2 w-[16.66%]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "truncate",
                                                children: "Lic Plates:"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 189,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-normal truncate ml-2",
                                                children: getAnswerValue(5)
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 190,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 188,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "p-2 text-center gap-2 w-[16.66%]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "truncate",
                                                children: "State:"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 195,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-normal truncate ml-2",
                                                children: getAnswerValue(6)
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 196,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 194,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 163,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 162,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                    className: "px-2 py-4 text-center",
                                    colSpan: 6,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-row justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-bold",
                                                children: "(✔) = Passed Inspection"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 206,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-bold",
                                                children: "X = Needs Further Attention"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 207,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-bold",
                                                children: "R = Repaired"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 208,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-bold",
                                                children: "N/A = Not Applicable"
                                            }, void 0, false, {
                                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                                lineNumber: 209,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 205,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 204,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 203,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 202,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 7).left ?? "",
                                    label1: "Verify unit #, registration, VIN plate, license plate current and legible. Current Federal sticker applied",
                                    repaired1: render(inspectionDetails, 7).right ?? "",
                                    check2: render(inspectionDetails, 8).left ?? "",
                                    label2: `Subframe - Inspect clamps, rail, slider pin assembly, pads, release and re-engage pins, stop bars,
crossmembers above slider rail**`,
                                    repaired2: render(inspectionDetails, 8).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 215,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 9).left ?? "",
                                    label1: `inspect 7-way receptacle, housing, electrical harness**`,
                                    repaired1: render(inspectionDetails, 9).right ?? "",
                                    check2: render(inspectionDetails, 10).left ?? "",
                                    label2: `Suspension - hangers, leaf springs, equalizers, torque arms**`,
                                    repaired2: render(inspectionDetails, 10).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 227,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 11).left ?? "",
                                    label1: `inspect lighting system, splice conditions**`,
                                    repaired1: render(inspectionDetails, 11).right ?? "",
                                    check2: render(inspectionDetails, 12).left ?? "",
                                    label2: `Inspect air lines, hoses, tanks, valves and brake chambers**`,
                                    repaired2: render(inspectionDetails, 12).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 236,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 13).left ?? "",
                                    label1: `inspect glad hands, air lines, protector**`,
                                    repaired1: render(inspectionDetails, 13).right ?? "",
                                    check2: render(inspectionDetails, 14).left ?? "",
                                    label2: `Brakes - drums, discs, brake lining, wheel seals**`,
                                    repaired2: render(inspectionDetails, 14).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 245,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 15).left ?? "",
                                    label1: `Verify Skybitz connectivity, Inspect for damage (if applicable)`,
                                    repaired1: render(inspectionDetails, 15).right ?? "",
                                    check2: render(inspectionDetails, 16).left ?? "",
                                    label2: `Lubricate slack adjusters, s-cams / Verify brake adjustment**`,
                                    repaired2: render(inspectionDetails, 16).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 254,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 17).left ?? "",
                                    label1: `Inspect Purkey's charging receptacles (if applicable)`,
                                    repaired1: render(inspectionDetails, 17).right ?? "",
                                    check2: render(inspectionDetails, 18).left ?? "",
                                    label2: `Proper lubricant level in each wheel (oil/grease)`,
                                    repaired2: render(inspectionDetails, 18).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 263,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 19).left ?? "",
                                    label1: `Pressurize air system, activate ABS System**`,
                                    repaired1: render(inspectionDetails, 19).right ?? "",
                                    check2: render(inspectionDetails, 20).left ?? "",
                                    label2: `Inspect wheels - lugnuts torqued to 450-500 ft-lbs`,
                                    repaired2: render(inspectionDetails, 20).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 272,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 21).left ?? "",
                                    label1: `Inspect Front Body condition and coupling device**`,
                                    repaired1: render(inspectionDetails, 21).right ?? "",
                                    check2: render(inspectionDetails, 22).left ?? "",
                                    label2: `Tires - Verify tire matching & application, tire inflation system set within 95 - 105 psi`,
                                    repaired2: render(inspectionDetails, 22).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 281,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 23).left ?? "",
                                    label1: `Mckinney decal package intact and legible`,
                                    repaired1: render(inspectionDetails, 23).right ?? "",
                                    check2: render(inspectionDetails, 24).left ?? "",
                                    label2: `Wheel End - Hub-caps, lugnuts, valve stems accessible, hubodometer (if applicable)`,
                                    repaired2: render(inspectionDetails, 24).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 290,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 25).left ?? "",
                                    label1: `Corner locking devices (if applicable)`,
                                    repaired1: render(inspectionDetails, 25).right ?? "",
                                    check2: render(inspectionDetails, 26).left ?? "",
                                    label2: `Metal flow through valve stem caps installed`,
                                    repaired2: render(inspectionDetails, 26).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 299,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 27).left ?? "",
                                    label1: `Inspect landing legs, k-brace, cross-shaft, wing plates, crossmembers - cycle and lubricate**`,
                                    repaired1: render(inspectionDetails, 27).right ?? "",
                                    check2: render(inspectionDetails, 28).left ?? "",
                                    label2: `Inspect pump box, batteries and load test (if applicable)`,
                                    repaired2: render(inspectionDetails, 28).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 308,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 29).left ?? "",
                                    label1: `Inspect undercarriage - crossmembers in Bay Area not to exceed 1/2" deflection`,
                                    repaired1: render(inspectionDetails, 29).right ?? "",
                                    check2: render(inspectionDetails, 30).left ?? "",
                                    label2: `Conspicuity tape - side panels, rear doors, ICC bumper, headboards**`,
                                    repaired2: render(inspectionDetails, 30).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 317,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 31).left ?? "",
                                    label1: `Inspect exterior side body conditions - rails, panels, posts, lift pads, pan hole covers**`,
                                    repaired1: render(inspectionDetails, 31).right ?? "",
                                    check2: render(inspectionDetails, 32).left ?? "",
                                    label2: `Aerodynamic Devices - side skirts, top kits, undertray (if applicable)`,
                                    repaired2: render(inspectionDetails, 32).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 326,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 33).left ?? "",
                                    label1: `Fuel tank and fuel system (reefer) (if applicable)`,
                                    repaired1: render(inspectionDetails, 33).right ?? "",
                                    check2: render(inspectionDetails, 34).left ?? "",
                                    label2: `Flatbed - Lubricate and cycle winch, Inspect headboard mounting hardware(if applicable)`,
                                    repaired2: render(inspectionDetails, 34).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 335,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 35).left ?? "",
                                    label1: `Test air ride suspension (if applicable)`,
                                    repaired1: render(inspectionDetails, 35).right ?? "",
                                    check2: render(inspectionDetails, 36).left ?? "",
                                    label2: `Swing Doors - Inspect panels, lock rod assemblies, hinges & hinges butts, pins, seals, comer tabs, anti-theft plate, holdbacks. Verify proper operation`,
                                    repaired2: render(inspectionDetails, 36).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 344,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 37).left ?? "",
                                    label1: `Roll Door - inspect panels, hinges, rollers, seals, operator - drums, springs, cable, track, aliggment, tension, latch, pull strap, track protector. Lubricate`,
                                    repaired1: render(inspectionDetails, 37).right ?? "",
                                    check2: render(inspectionDetails, 38).left ?? "",
                                    label2: `Interior - Roof, roof bows, post, e-tracks, threshold plate, scuffliners, flooring secured, plywood, liners`,
                                    repaired2: render(inspectionDetails, 38).right ?? ""
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 353,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LineTable, {
                                    check1: render(inspectionDetails, 39).left ?? "",
                                    label1: `Rear Frame - Rear sill, rear corner posdts, header, ICC bumper assembly, dock bumpers** (ICC)`,
                                    repaired1: render(inspectionDetails, 39).right ?? "",
                                    check2: "",
                                    label2: ``,
                                    repaired2: "",
                                    disable2column: true
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 362,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 214,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 161,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 160,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "my-5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "font-bold",
                    children: "**By signing and dating this form the Inspector certifies (I) the accuracy and completeness of the Inspection of this vehicle in compliance with all of the requirements of 49 C.F.R. Part 396 and (II) the vehicle has passed Inspection in accordance with 49 C.F.R. Part 396.17**"
                }, void 0, false, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 375,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 374,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "my-5 flex flex-col xl:flex-row gap-5 ",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-2 ",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 flex-1 gap-2 items-center justify-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxData, {
                                        title: "RFO",
                                        label1: "Brand:",
                                        data1: getAnswerValue(40),
                                        label2: "32nda:",
                                        data2: getAnswerValue(41),
                                        label3: "O/C:",
                                        data3: getAnswerValue(42),
                                        label4: "PSI:",
                                        data4: getAnswerValue(43)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 386,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxData, {
                                        title: "RCO",
                                        label1: "Brand:",
                                        data1: getAnswerValue(44),
                                        label2: "32nda:",
                                        data2: getAnswerValue(45),
                                        label3: "O/C:",
                                        data3: getAnswerValue(46),
                                        label4: "PSI:",
                                        data4: getAnswerValue(47)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 397,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxData, {
                                        title: "RRO",
                                        label1: "Brand:",
                                        data1: getAnswerValue(48),
                                        label2: "32nda:",
                                        data2: getAnswerValue(49),
                                        label3: "O/C:",
                                        data3: getAnswerValue(50),
                                        label4: "PSI:",
                                        data4: getAnswerValue(51)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 408,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxData, {
                                        title: "RDA",
                                        label1: "Brand:",
                                        data1: getAnswerValue(52),
                                        label2: "32nda:",
                                        data2: getAnswerValue(53),
                                        label3: "O/C:",
                                        data3: getAnswerValue(54),
                                        label4: "PSI:",
                                        data4: getAnswerValue(55)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 420,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxData, {
                                        title: "RFI",
                                        label1: "Brand:",
                                        data1: getAnswerValue(56),
                                        label2: "32nda:",
                                        data2: getAnswerValue(57),
                                        label3: "O/C:",
                                        data3: getAnswerValue(58),
                                        label4: "PSI:",
                                        data4: getAnswerValue(59)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 432,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxData, {
                                        title: "RCI",
                                        label1: "Brand:",
                                        data1: getAnswerValue(60),
                                        label2: "32nda:",
                                        data2: getAnswerValue(61),
                                        label3: "O/C:",
                                        data3: getAnswerValue(62),
                                        label4: "PSI:",
                                        data4: getAnswerValue(63)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 444,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxData, {
                                        title: "RRI",
                                        label1: "Brand:",
                                        data1: getAnswerValue(64),
                                        label2: "32nda:",
                                        data2: getAnswerValue(65),
                                        label3: "O/C:",
                                        data3: getAnswerValue(66),
                                        label4: "PSI:",
                                        data4: getAnswerValue(67)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 456,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "RDA /8ths",
                                        data1: getAnswerValue(68)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 468,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 385,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 flex-1 gap-2 items-center justify-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "RF /8ths",
                                        data1: getAnswerValue(69)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 471,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "RC /8ths",
                                        data1: getAnswerValue(70)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 472,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "RR /8ths",
                                        data1: getAnswerValue(71)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 473,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmallLine, {
                                        label: "Tire Size:",
                                        value: getAnswerValue(75)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 474,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LF /8ths",
                                        data1: getAnswerValue(72)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 475,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LC /8ths",
                                        data1: getAnswerValue(73)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 476,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LR /8ths",
                                        data1: getAnswerValue(74)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 477,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmallLine, {
                                        label: "Mileage:",
                                        value: getAnswerValue(76)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 478,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LFI Brand",
                                        data1: getAnswerValue(77)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 479,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LFI 32nda",
                                        data1: getAnswerValue(78)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 480,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LFI O/C",
                                        data1: getAnswerValue(79)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 481,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LFI PSI",
                                        data1: getAnswerValue(80)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 482,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LCI Brand",
                                        data1: getAnswerValue(81)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 483,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LCI 32nda",
                                        data1: getAnswerValue(82)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 484,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LCI O/C",
                                        data1: getAnswerValue(83)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 485,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LCI PSI",
                                        data1: getAnswerValue(84)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 486,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LRI Brand",
                                        data1: getAnswerValue(85)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 487,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LRI 32nda",
                                        data1: getAnswerValue(86)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 488,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LRI O/C",
                                        data1: getAnswerValue(87)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 489,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LRI PSI",
                                        data1: getAnswerValue(88)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 490,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LFO Brand",
                                        data1: getAnswerValue(89)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 491,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LFO 32nda",
                                        data1: getAnswerValue(90)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 492,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LFO O/C",
                                        data1: getAnswerValue(91)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 493,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LFO PSI",
                                        data1: getAnswerValue(92)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 494,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LCO Brand",
                                        data1: getAnswerValue(93)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 495,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LCO 32nda",
                                        data1: getAnswerValue(94)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 496,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LCO O/C",
                                        data1: getAnswerValue(95)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 497,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LCO PSI",
                                        data1: getAnswerValue(96)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 498,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LRO Brand",
                                        data1: getAnswerValue(97)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 499,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LRO 32nda",
                                        data1: getAnswerValue(98)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 500,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LRO O/C",
                                        data1: getAnswerValue(99)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 501,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LRO PSI",
                                        data1: getAnswerValue(100)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 502,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LDA Brand",
                                        data1: getAnswerValue(101)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 503,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LDA 32nda",
                                        data1: getAnswerValue(102)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 504,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LDA O/C",
                                        data1: getAnswerValue(103)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 505,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LDA PSI",
                                        data1: getAnswerValue(104)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 506,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmall, {
                                        label1: "LDA /8ths",
                                        data1: getAnswerValue(105)
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                        lineNumber: 507,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 470,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                        lineNumber: 384,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-[300px]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "border rounded-lg",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-bold p-2",
                                    children: "Comments:"
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 512,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[14px] block p-5",
                                    children: [
                                        getAnswerValue(106),
                                        " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Architecto, placeat eum voluptatem nobis ullam ab ipsa deserunt exercitationem minima molestias quod velit illo illum fuga ea suscipit explicabo laborum assumenda."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 513,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 511,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                        lineNumber: 510,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 383,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "my-5 mt-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-row",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full md:w-1/2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmallLine, {
                                label: "Company Name:",
                                value: getAnswerValue(107),
                                className: "!border-0",
                                font: `text-normal`
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 525,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 524,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                        lineNumber: 523,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-3 md:flex-row",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full md:w-1/2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmallLine, {
                                    label: "Inspector Name Printed:",
                                    value: "",
                                    className: "!border-0 ",
                                    font: `text-normal`
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 535,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 534,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full md:w-1/2 relative top-[12px]",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmallLine, {
                                    label: "Inspection Conducted By:",
                                    value: getAnswerValue(109),
                                    className: "!border-0",
                                    font: `text-normal`,
                                    signature: `(Inspector Signature)`
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 543,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 542,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full md:w-1/2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoxDataSmallLine, {
                                    label: "Inspection date:",
                                    value: getAnswerValue(110),
                                    className: "!border-0 ",
                                    font: `text-normal`
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                    lineNumber: 552,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 551,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                        lineNumber: 533,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 522,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
_c = MckinneyFederalInspection;
const __TURBOPACK__default__export__ = MckinneyFederalInspection;
const LineTable = ({ check1 = false, label1, repaired1 = false, disable1column = null, check2 = false, label2, repaired2 = false, disable2column = null })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "px-2 py-4 text-center",
                children: disable1column === null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-row items-center justify-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "["
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 593,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-bold",
                            children: check1 ? check1 : ``
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 594,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "]"
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 595,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 592,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 590,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "px-2 py-4 left",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: label1
                }, void 0, false, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 600,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 599,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "px-2 py-4 text-center",
                children: disable1column === null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-row items-center justify-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "["
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 605,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-bold",
                            children: repaired1 ? repaired1 : ``
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 606,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "]"
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 607,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                children: "Repaired"
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 609,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 608,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 604,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 602,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "px-2 py-4 text-center pl-20",
                children: disable2column === null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-row items-center justify-center gap-3 ",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "["
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 617,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-bold",
                            children: check2 ? check2 : ``
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 618,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "]"
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 619,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 616,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 614,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "px-2 py-4 left",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: label2
                }, void 0, false, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 624,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 623,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "px-2 py-4 text-center",
                children: disable2column === null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-row items-center justify-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "["
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 629,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-bold",
                            children: repaired2 ? repaired2 : ``
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 630,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "]"
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 631,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                children: "Repaired"
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 633,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 632,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 628,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 626,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
        lineNumber: 589,
        columnNumber: 5
    }, this);
};
_c1 = LineTable;
const BoxData = ({ title, label1, data1, label2, data2, label3, data3, label4, data4 })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-lg border w-full px-2 py-1 gap-3 flex flex-col ",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "font-bold  ",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 667,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-row",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-1/2 flex flex-row gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-bold text-sm whitespace-nowrap",
                                children: label1
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 670,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "border-b w-full text-center",
                                value: data1
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 671,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                        lineNumber: 669,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-1/2 flex flex-row gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-bold text-sm whitespace-nowrap",
                                children: label2
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 678,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "border-b w-full text-center",
                                value: data2
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 679,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                        lineNumber: 677,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 668,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-row",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-1/2 flex flex-row gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-bold text-sm whitespace-nowrap",
                                children: label3
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 688,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "border-b w-full text-center",
                                value: data3
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 689,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                        lineNumber: 687,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-1/2 flex flex-row gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-bold text-sm whitespace-nowrap",
                                children: label4
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 696,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "border-b w-full text-center",
                                value: data4
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 697,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                        lineNumber: 695,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                lineNumber: 686,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
        lineNumber: 666,
        columnNumber: 5
    }, this);
};
_c2 = BoxData;
const BoxDataSmall = ({ label1, label2, data1, data2 })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-lg border w-full px-2 py-1 gap-5 flex items-center justify-center h-[50px]",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-row w-full items-center gap-1 px-25 md:px-8 justify-between",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "font-bold text-sm whitespace-nowrap",
                    children: label1
                }, void 0, false, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 724,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "text",
                    defaultValue: data1,
                    className: " w-full text-center"
                }, void 0, false, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 725,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
            lineNumber: 723,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
        lineNumber: 722,
        columnNumber: 5
    }, this);
};
_c3 = BoxDataSmall;
const BoxDataSmallLine = ({ label, value, className, font = `text-md`, signature = null })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`rounded-lg border w-full px-2 py-1 gap-5 flex items-center justify-center h-[50px]`, className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col w-full items-center gap-1 ",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-row items-center gap-1 w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`font-bold  whitespace-nowrap`, font),
                            children: label
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 759,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`font-bold  w-full`, font),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "border-b w-full text-center font-normal",
                                defaultValue: value
                            }, void 0, false, {
                                fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                                lineNumber: 763,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 762,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 758,
                    columnNumber: 9
                }, this),
                signature !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-row items-center gap-1 w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`font-bold  whitespace-nowrap invisible`, font),
                            children: label
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 772,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(` !text-[11px] text-center w-full`, font),
                            children: signature
                        }, void 0, false, {
                            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                            lineNumber: 777,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
                    lineNumber: 771,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
            lineNumber: 757,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/shared/components/shared/InspectionsPdf/MckinneyFederalInspection.tsx",
        lineNumber: 751,
        columnNumber: 5
    }, this);
};
_c4 = BoxDataSmallLine;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "MckinneyFederalInspection");
__turbopack_context__.k.register(_c1, "LineTable");
__turbopack_context__.k.register(_c2, "BoxData");
__turbopack_context__.k.register(_c3, "BoxDataSmall");
__turbopack_context__.k.register(_c4, "BoxDataSmallLine");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=1ab64_shared_components_shared_InspectionsPdf_MckinneyFederalInspection_tsx_9b7b9484._.js.map