(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_9adf23fd._.js",
  "static/chunks/src_6837e729._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
  "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
  "static/chunks/node_modules_html2canvas_dist_html2canvas_3938cdad.js",
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e70f.js",
  "static/chunks/node_modules_html2canvas-pro_dist_html2canvas-pro_136ea222.js",
  "static/chunks/node_modules_3731644b._.js"
],
    source: "dynamic"
});
