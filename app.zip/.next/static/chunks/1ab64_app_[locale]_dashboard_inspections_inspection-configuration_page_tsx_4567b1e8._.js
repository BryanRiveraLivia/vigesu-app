(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_78df2b41._.js",
  "static/chunks/node_modules_lodash_6b0ce4b3._.js",
  "static/chunks/src_c077c4a1._.js"
],
    source: "dynamic"
});
