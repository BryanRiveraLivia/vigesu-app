(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_95cb5058._.js",
  "static/chunks/b2e40_components_shared_InspectionsPdf_ChassisAnnualInspectionReport_tsx_24b5b5ca._.js",
  "static/chunks/6d2c2_shared_InspectionsPdf_ChassisAnnualInspectionReportDayPM_tsx_6d205438._.js",
  "static/chunks/1ab64_shared_components_shared_InspectionsPdf_MckinneyFederalInspection_tsx_9b7b9484._.js",
  "static/chunks/src_shared_components_shared_InspectionsPdf_InspectionTTN_tsx_e62fc83b._.js",
  "static/chunks/src_shared_components_shared_InspectionsPdf_c3596742._.js",
  "static/chunks/src_shared_components_shared_c1634abe._.js",
  "static/chunks/src_shared_71a1ac47._.js",
  "static/chunks/src_a8723a8b._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
  "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
  "static/chunks/node_modules_html2canvas-pro_dist_html2canvas-pro_136ea222.js",
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e70f.js",
  "static/chunks/node_modules_next_15251bc2._.js",
  "static/chunks/node_modules_3731644b._.js"
],
    source: "dynamic"
});
