(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_d265efdb._.js",
  "static/chunks/node_modules_zod_d2f1a96c._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
  "static/chunks/node_modules_react-icons_io_index_mjs_d35cf443._.js",
  "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
  "static/chunks/node_modules_react-icons_gr_index_mjs_42e3d99f._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_78df2b41._.js",
  "static/chunks/node_modules_41ecc805._.js"
],
    source: "dynamic"
});
