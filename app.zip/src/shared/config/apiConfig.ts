// src/shared/config/apiConfig.ts

export const API_CONFIG = {
  BASE_URL: "https://ronny998909-001-site1.qtempurl.com/api",
};
