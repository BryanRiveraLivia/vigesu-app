import React from "react";

const FormatOne = () => {
  return <div>FormatOne</div>;
};

export default FormatOne;
