const config = {
  locales: ["en", "es"],
  defaultLocale: "en",
  localePrefix: "as-needed", // o 'alwa
  localeDetection: false, // 👈 opcional, mantén todo alineadoys'
};

export default config;
